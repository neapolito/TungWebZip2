# TungNet

A brown, wood-carved web proxy. Type any website or search and it opens **inside the TungNet page**: in-page tabs, back and forward, no new browser tabs. Paste a YouTube link into **Tung's Theater** and it plays right there. Tung, the wooden mascot, keeps watch from the porch.

## Run it in a GitHub Codespace

1. Make a new GitHub repository and upload everything in this folder, including the hidden `.devcontainer` folder.
   - Easiest way: on the new repo page click **uploading an existing file** and drag the whole unzipped folder in.
   - If `.devcontainer` doesn't come along (some systems hide dot-folders), create the file `.devcontainer/devcontainer.json` in GitHub and paste its contents in.
2. On the repo page click **Code → Codespaces → Create codespace on main**.
3. Wait about a minute. The Codespace runs `npm install`, then `npm start`, and opens TungNet in a new browser tab.
   - If no tab opens, go to the **Ports** tab at the bottom of VS Code, find port **8080**, and click the globe icon.
4. TungNet opens on a lock screen. Type the password **`0128`** and press Go.
5. Now type a site (for example `wikipedia.org`) or a search and press **Go**.

**Shortcut without making a repo first:** go to github.com/codespaces, start a **Blank** codespace, drag `tungnet.zip` into its file list, then in the terminal run `unzip tungnet.zip && cd tungnet && npm install && npm start` and open the port 8080 link it shows.

Starting it yourself in the Codespace terminal:

```bash
npm install
npm start
```

TungNet must be opened through the **https://…app.github.dev** link Codespaces gives you, because the proxy engine needs HTTPS (or `localhost`).

## Run it on your own computer

You need Node.js 20 or newer.

```bash
npm install
npm start
```

Then open http://localhost:8080. Use another port with `PORT=3000 npm start`.

## Password lock

TungNet opens on a lock screen. Nothing loads — not the app, not the proxy — until you enter the password. The default is **`0128`**.

- **Change it:** set `TUNGNET_PASSWORD` when you start it, e.g. `TUNGNET_PASSWORD=mysecret npm start`. In a Codespace you can add it under the repo's **Settings → Secrets and variables → Codespaces**.
- **Turn it off:** `TUNGNET_NO_LOCK=1 npm start`.
- **Lock it again** without closing the Codespace: go to Settings → Password lock → **Lock now**.

The check happens on the server, so the password isn't stored in the page. Sessions are kept in memory, so restarting the server signs everyone out. This keeps strangers who find your Codespace link from using your proxy; it isn't high-security, so don't reuse an important password.

## What's inside

| Part | What it does |
| --- | --- |
| **Browse** | In-page tabs, address bar with live search suggestions, back/forward/reload, fullscreen, pin pages with the star |
| **Theater** | Plays YouTube links (watch, youtu.be, Shorts, live, embed, playlists, `t=` timestamps) through the privacy-friendly youtube-nocookie player. Queue that auto-plays the next video, recently played list, cinema mode, and a one-click "open on YouTube" for videos that block embedding |
| **Arcade** | Six original games built from scratch — Gridiron Dash (football), Tung Hoops (basketball), Tung Breaker, Tung Flap, Timber Snake, and Log Stack (2048). Keyboard and touch, high scores saved on your device |
| **Settings** | Search engine (DuckDuckGo, Google, Bing, Brave), proxy connection (Epoxy or libcurl), Tung's quips and knock sound, clear your data |
| **Tung** | Splash screen, carved sign, porch hero with tips (click him), rolling face on the load bar, "tung tung TUNG!" stamp with a synthesized wood knock, peeking over the Theater stage, 404 page |

Shortcuts: `/` jumps to search, `Alt+T` new tab, `Alt+W` close tab, `Alt+L` edit the address, Ctrl-click a link for a background tab.

Links that try to open a new window (`target="_blank"`, `window.open`) open as a new TungNet tab instead.

## How it works

```
your browser                                         the server (server.js)
┌──────────────────────────────┐                   ┌──────────────────────────┐
│ TungNet page                 │                   │ serves /public           │
│  └ iframe /uv/service/<url>  │──fetch──┐         │ serves engine files      │
│      ▲                       │         ▼         │  /uv  /baremux  /epoxy   │
│      │   Ultraviolet service worker rewrites     │  /libcurl                │
│      │   every page and request so it stays      │                          │
│      │   inside TungNet                          │ /wisp/ WebSocket ───────────► the real website
│      └── bare-mux + Epoxy/libcurl ═══ Wisp ══════│                          │
└──────────────────────────────┘                   └──────────────────────────┘
```

- **Ultraviolet** (service worker) rewrites pages so links, scripts and requests stay in the proxy.
- **bare-mux** with the **Epoxy** or **libcurl** transport makes encrypted connections from the browser.
- **Wisp** (`@mercuryworkshop/wisp-js`) is the WebSocket tunnel on the server that reaches the real sites.
- `server.js` uses only Node's built-in `http` module. It also adds small helpers: search suggestions (`/api/suggest`), YouTube titles (`/api/yt/info`) and thumbnails (`/api/yt/thumb/:id`).

Server options (environment variables):

| Variable | Default | Meaning |
| --- | --- | --- |
| `PORT` | `8080` | Port to listen on |
| `HOST` | `0.0.0.0` | Interface to listen on |
| `DEBUG` | off | `DEBUG=1` prints Wisp connection logs |
| `ALLOW_LOCAL` | off | `ALLOW_LOCAL=1` lets the proxy reach private/localhost addresses (off by default so pages can't poke at your Codespace) |
| `TUNGNET_PASSWORD` | `0128` | The lock-screen password |
| `TUNGNET_NO_LOCK` | off | `TUNGNET_NO_LOCK=1` opens TungNet with no password |

## Files

```
server.js                    the server
package.json                 dependencies + npm start
.devcontainer/               Codespaces setup (Node 22, port 8080, auto start)
public/index.html            the app
public/css/tungnet.css       the brown wood theme
public/js/app.js             wires everything together
public/js/engine.js          starts the proxy engine
public/js/browser.js         tabs, address bar, history, link catching
public/js/theater.js         YouTube player, queue, recent list
public/js/arcade.js          the games grid and play screen
public/js/games/             the arcade: engine.js + one file per game
public/js/settings.js        settings screen
public/js/suggest.js         search suggestion dropdown
public/js/tung.js            Tung's quips, knock sound, stamp, toasts
public/js/store.js           saved settings, pins, history (this browser only)
public/uv/uv.config.js       Ultraviolet config
public/uv/sw.js              service worker
public/gate.html             the password lock screen
public/warmup.html           starts the engine if a proxied page loads first
public/404.html              Tung's not-found page
public/img/                  Tung pictures and icons
```

## Troubleshooting

- **The lamp in the header says "Lamp out".** Click it for the reason. Usually you opened the `http://` address; use the `https://…app.github.dev` link. If it says engine files are missing, run `npm install`.
- **A site won't load or looks broken.** Go to Settings and switch the proxy connection to libcurl, then reload the page. Big apps with heavy logins (Discord, some Google sign-ins) may not fully work through any web proxy.
- **Google asks "are you a robot?"** Switch the search engine to DuckDuckGo or Brave in Settings.
- **A YouTube video says it's unavailable.** Some videos don't allow embedding. Press the open-in-tab button under the player to watch it on YouTube inside a TungNet tab.
- **Pages fail to connect in the Codespace.** In the Ports tab, right-click port 8080 → Port Visibility → Public, then reload.
- **"Port 8080 is already in use."** TungNet is already running (Codespaces starts it for you). Use the open tab, or stop the other copy with Ctrl+C.

## Good to know

- Pinned sites, history and settings are saved in your browser only, never on the server.
- Use it on networks where you're allowed to, and follow your school's or workplace's rules.
- The proxy engine packages have their own licenses: Ultraviolet (AGPL-3.0), Epoxy and libcurl transports, bare-mux and wisp-js (see each package in `node_modules`).
