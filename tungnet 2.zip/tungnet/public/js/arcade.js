// Tung Arcade: the games grid and the play screen.

import { loadBest, saveBest } from "./games/engine.js";
import gridiron from "./games/gridiron.js";
import hoops from "./games/hoops.js";
import snake from "./games/snake.js";
import blocks from "./games/blocks.js";
import brick from "./games/brick.js";
import flap from "./games/flap.js";
import { toast } from "./tung.js";

const GAMES = [gridiron, hoops, brick, flap, snake, blocks];
const $ = (id) => document.getElementById(id);

let current = null; // { def, instance }
const els = {};

function cardThumb(def) {
  // A simple on-brand badge: the emoji on a wooden coin tinted with the accent.
  const el = document.createElement("div");
  el.className = "game-thumb";
  el.style.setProperty("--accent", def.accent || "#f2a33a");
  el.innerHTML = `<span class="game-emoji">${def.emoji || "🎮"}</span>`;
  return el;
}

function renderGrid() {
  const frag = document.createDocumentFragment();
  for (const def of GAMES) {
    const li = document.createElement("li");
    const card = document.createElement("button");
    card.type = "button";
    card.className = "game-card";
    card.style.setProperty("--accent", def.accent || "#f2a33a");
    card.append(cardThumb(def));
    const body = document.createElement("div");
    body.className = "game-card-body";
    const top = document.createElement("div");
    top.className = "game-card-top";
    top.innerHTML = `<span class="game-card-name">${def.name}</span><span class="game-tag">${def.tag}</span>`;
    const blurb = document.createElement("p");
    blurb.className = "game-card-blurb";
    blurb.textContent = def.blurb;
    const best = document.createElement("span");
    best.className = "game-card-best";
    const b = loadBest(def.id);
    best.textContent = b ? `Best ${b}` : "Not played yet";
    body.append(top, blurb, best);
    const play = document.createElement("span");
    play.className = "game-card-play";
    play.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-play"/></svg>';
    card.append(body, play);
    card.addEventListener("click", () => launch(def));
    li.append(card);
    frag.append(li);
  }
  els.grid.replaceChildren(frag);
}

function launch(def) {
  destroyCurrent();
  els.browse.hidden = true;
  els.play.hidden = false;
  els.name.textContent = def.name;
  els.controls.textContent = def.controls || "";
  els.score.textContent = "0";
  const best = loadBest(def.id);
  els.best.textContent = best ? `best ${best}` : "";
  els.pause.dataset.state = "playing";
  els.pause.querySelector("use").setAttribute("href", "#i-pause");
  els.host.replaceChildren();

  const api = {
    setScore(n) {
      els.score.textContent = String(n);
    },
    gameOver(n) {
      const prev = loadBest(def.id);
      const b = saveBest(def.id, n);
      els.best.textContent = `best ${b}`;
      if (n > prev && n > 0) toast(`New best in ${def.name}: ${n}!`);
    },
    best: () => loadBest(def.id),
    isTouch: matchMedia("(hover: none)").matches,
  };

  const instance = def.make(els.host, api);
  current = { def, instance };
}

function destroyCurrent() {
  if (!current) return;
  try {
    current.instance.destroy();
  } catch {
    /* ignore */
  }
  current = null;
}

function closeGame() {
  destroyCurrent();
  els.play.hidden = true;
  els.browse.hidden = false;
  renderGrid(); // refresh best scores
}

function togglePause() {
  if (!current) return;
  const playing = els.pause.dataset.state !== "paused";
  if (playing) {
    current.instance.pause?.();
    els.pause.dataset.state = "paused";
    els.pause.querySelector("use").setAttribute("href", "#i-play");
    els.host.classList.add("paused");
  } else {
    current.instance.resume?.();
    els.pause.dataset.state = "playing";
    els.pause.querySelector("use").setAttribute("href", "#i-pause");
    els.host.classList.remove("paused");
  }
}

export function initArcade() {
  Object.assign(els, {
    browse: $("arcade-browse"),
    grid: $("arcade-grid"),
    play: $("arcade-play"),
    host: $("game-host"),
    name: $("game-name"),
    score: $("game-score"),
    best: $("game-best"),
    controls: $("game-controls"),
    back: $("game-back"),
    restart: $("game-restart"),
    pause: $("game-pause"),
  });

  els.back.addEventListener("click", closeGame);
  els.restart.addEventListener("click", () => current && launch(current.def));
  els.pause.addEventListener("click", togglePause);

  // Leaving the arcade closes the game, so its key handling never lingers on
  // other views. Hiding the tab just pauses it.
  document.addEventListener("tungnet:view", (e) => {
    if (e.detail !== "arcade" && current) closeGame();
  });
  document.addEventListener("visibilitychange", () => {
    if (!current || els.play.hidden) return;
    if (document.hidden) current.instance.pause?.();
    else if (els.pause.dataset.state !== "paused" && document.body.dataset.section === "arcade") current.instance.resume?.();
  });

  renderGrid();
}
