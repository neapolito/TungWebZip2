// Suggestion dropdown for the address bar and the home search plank.
// Mixes your recent pages with live search suggestions from the server.

import { history, prettyHost } from "./store.js";

let uid = 0;

export function attachSuggest(input, { onPick }) {
  const list = document.createElement("ul");
  const id = `suggest-${++uid}`;
  list.className = "suggest";
  list.id = id;
  list.setAttribute("role", "listbox");
  list.hidden = true;
  input.after(list);
  input.setAttribute("role", "combobox");
  input.setAttribute("aria-autocomplete", "list");
  input.setAttribute("aria-controls", id);
  input.setAttribute("aria-expanded", "false");

  let items = [];
  let active = -1;
  let timer = 0;
  let inflight = null;
  let typed = "";

  function close() {
    list.hidden = true;
    input.setAttribute("aria-expanded", "false");
    input.removeAttribute("aria-activedescendant");
    active = -1;
  }

  function render() {
    list.replaceChildren();
    if (!items.length) return close();
    items.forEach((item, i) => {
      const li = document.createElement("li");
      li.id = `${id}-${i}`;
      li.setAttribute("role", "option");
      li.className = "suggest-item " + item.type;
      li.setAttribute("aria-selected", String(i === active));
      const icon = document.createElement("span");
      icon.className = "suggest-icon";
      icon.innerHTML =
        item.type === "history"
          ? '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-clock"/></svg>'
          : '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-search"/></svg>';
      const text = document.createElement("span");
      text.className = "suggest-text";
      text.textContent = item.label;
      li.append(icon, text);
      if (item.type === "history") {
        const meta = document.createElement("span");
        meta.className = "suggest-meta";
        meta.textContent = prettyHost(item.url);
        li.append(meta);
      }
      li.addEventListener("mousedown", (e) => {
        e.preventDefault();
        close();
        onPick(item);
      });
      list.append(li);
    });
    list.hidden = false;
    input.setAttribute("aria-expanded", "true");
    if (active >= 0) input.setAttribute("aria-activedescendant", `${id}-${active}`);
    else input.removeAttribute("aria-activedescendant");
  }

  async function update() {
    const q = input.value.trim();
    if (!q) {
      items = history.slice(0, 5).map((h) => ({ type: "history", label: h.title || prettyHost(h.url), url: h.url }));
      active = -1;
      return render();
    }
    const lower = q.toLowerCase();
    const local = history
      .filter((h) => h.url.toLowerCase().includes(lower) || (h.title || "").toLowerCase().includes(lower))
      .slice(0, 3)
      .map((h) => ({ type: "history", label: h.title || prettyHost(h.url), url: h.url }));
    items = local;
    active = -1;
    render();

    inflight?.abort();
    const ctrl = new AbortController();
    inflight = ctrl;
    try {
      const r = await fetch("/api/suggest?q=" + encodeURIComponent(q), { signal: ctrl.signal });
      const data = await r.json();
      if (ctrl.signal.aborted || input.value.trim() !== q) return;
      const remote = (data.suggestions || [])
        .filter((s) => s.toLowerCase() !== lower)
        .slice(0, 6 - local.length)
        .map((s) => ({ type: "search", label: s, text: s }));
      items = [...local, ...remote];
      if (document.activeElement === input) render();
    } catch {
      /* offline or aborted: local results are enough */
    }
  }

  input.addEventListener("input", () => {
    clearTimeout(timer);
    timer = setTimeout(update, 130);
  });
  input.addEventListener("focus", () => {
    clearTimeout(timer);
    timer = setTimeout(update, 60);
  });
  input.addEventListener("blur", () => setTimeout(close, 120));
  input.addEventListener("keydown", (e) => {
    if (list.hidden || !items.length) return;
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      if (active === -1) typed = input.value;
      let next = active + (e.key === "ArrowDown" ? 1 : -1);
      if (next >= items.length) next = -1;
      if (next < -1) next = items.length - 1;
      active = next;
      render();
      const item = items[active];
      input.value = item ? (item.type === "history" ? item.url : item.text) : typed;
    } else if (e.key === "Escape") {
      close();
    } else if (e.key === "Enter" && active >= 0) {
      e.preventDefault();
      const item = items[active];
      close();
      onPick(item);
    }
  });

  return { close };
}
