// Tung: the wooden mascot. Quips, the knock sound, and the "tung tung TUNG!" stamp.

import { settings } from "./store.js";

export const QUIPS = [
  "Type a site or a search. I'll fetch it right here.",
  "Tung tung tung… where are we going?",
  "Every page opens inside TungNet. No new tabs, promise.",
  "Got a YouTube link? Take it to the Theater.",
  "I carry this bat strictly for browsing purposes.",
  "Pin the sites you visit most so I remember them.",
  "Ctrl-click a link to send it to a background tab.",
  "Bonk the star in the toolbar to pin the page you're on.",
  "Night shift again. Good thing the lamp's on.",
];

let quipIndex = Math.floor(Math.random() * QUIPS.length);
export function nextQuip() {
  quipIndex = (quipIndex + 1 + Math.floor(Math.random() * (QUIPS.length - 1))) % QUIPS.length;
  return QUIPS[quipIndex];
}
export function currentQuip() {
  return QUIPS[quipIndex];
}

export const reducedMotion = () => matchMedia("(prefers-reduced-motion: reduce)").matches;

// ---------------------------------------------------------------------------
// Knock sound: a hollow wooden "tung", synthesized, no audio files needed.
// ---------------------------------------------------------------------------

let audio = null;
function ctx() {
  if (!audio) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    audio = new AC();
  }
  if (audio.state === "suspended") audio.resume().catch(() => {});
  return audio;
}

function knockAt(ac, t, pitch, volume) {
  const out = ac.createGain();
  out.gain.setValueAtTime(0.0001, t);
  out.gain.exponentialRampToValueAtTime(volume, t + 0.004);
  out.gain.exponentialRampToValueAtTime(0.0001, t + 0.28);
  out.connect(ac.destination);

  // body of the log
  const body = ac.createOscillator();
  body.type = "sine";
  body.frequency.setValueAtTime(pitch * 1.6, t);
  body.frequency.exponentialRampToValueAtTime(pitch, t + 0.05);
  body.connect(out);
  body.start(t);
  body.stop(t + 0.3);

  // woody overtone
  const tone = ac.createOscillator();
  const toneGain = ac.createGain();
  tone.type = "triangle";
  tone.frequency.setValueAtTime(pitch * 2.76, t);
  toneGain.gain.setValueAtTime(0.35, t);
  toneGain.gain.exponentialRampToValueAtTime(0.0001, t + 0.09);
  tone.connect(toneGain).connect(out);
  tone.start(t);
  tone.stop(t + 0.12);

  // the bat hitting the wood
  const len = Math.floor(ac.sampleRate * 0.03);
  const buf = ac.createBuffer(1, len, ac.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / len) ** 3;
  const click = ac.createBufferSource();
  const band = ac.createBiquadFilter();
  band.type = "bandpass";
  band.frequency.value = 1900;
  band.Q.value = 1.2;
  click.buffer = buf;
  click.connect(band).connect(out);
  click.start(t);
}

/** Play the knock pattern: tung, tung, TUNG. */
export function knock(times = 3) {
  if (!settings.sound) return;
  const ac = ctx();
  if (!ac) return;
  const t0 = ac.currentTime + 0.01;
  for (let i = 0; i < times; i++) {
    const last = i === times - 1;
    knockAt(ac, t0 + i * 0.14, last ? 150 : 185, last ? 0.5 : 0.32);
  }
}

// ---------------------------------------------------------------------------
// The stamp: "tung tung TUNG!" thumps in near whatever you just used.
// ---------------------------------------------------------------------------

let popTimer = 0;
export function stamp(anchor) {
  knock(3);
  const pop = document.getElementById("tung-pop");
  if (!pop || reducedMotion()) return;
  const box = anchor?.getBoundingClientRect?.();
  if (box && box.width) {
    const half = (pop.offsetWidth || 300) / 2 + 10;
    const x = Math.min(window.innerWidth - half, Math.max(half, box.left + box.width / 2));
    const y = Math.max(70, box.top - 8);
    pop.style.setProperty("--x", x + "px");
    pop.style.setProperty("--y", y + "px");
  }
  pop.classList.remove("show");
  void pop.offsetWidth; // restart the animation
  pop.classList.add("show");
  clearTimeout(popTimer);
  popTimer = setTimeout(() => pop.classList.remove("show"), 1100);
}

/** Make an element (Tung's picture) do a little bonk wobble. */
export function wobble(el) {
  if (!el || reducedMotion()) return;
  el.classList.remove("wobble");
  void el.offsetWidth;
  el.classList.add("wobble");
}

// ---------------------------------------------------------------------------
// Toasts
// ---------------------------------------------------------------------------

let toastTimer = 0;
export function toast(message) {
  const el = document.getElementById("toast");
  if (!el) return;
  el.querySelector(".toast-text").textContent = message;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2600);
}
