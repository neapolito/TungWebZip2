// Tiny localStorage wrapper. Everything TungNet remembers lives in this browser only.

const PREFIX = "tungnet.";

export function load(key, fallback) {
  try {
    const raw = localStorage.getItem(PREFIX + key);
    return raw == null ? structuredClone(fallback) : JSON.parse(raw);
  } catch {
    return structuredClone(fallback);
  }
}

export function save(key, value) {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(value));
  } catch {
    /* storage full or blocked: keep going in memory */
  }
}

export function clear(key) {
  try {
    localStorage.removeItem(PREFIX + key);
  } catch {
    /* ignore */
  }
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------

export const SEARCH_ENGINES = {
  duckduckgo: { name: "DuckDuckGo", url: "https://duckduckgo.com/?q=%s" },
  google: { name: "Google", url: "https://www.google.com/search?q=%s" },
  bing: { name: "Bing", url: "https://www.bing.com/search?q=%s" },
  brave: { name: "Brave Search", url: "https://search.brave.com/search?q=%s" },
};

const DEFAULT_SETTINGS = {
  engine: "epoxy", // proxy transport: "epoxy" or "libcurl"
  search: "duckduckgo",
  quips: true, // Tung talks on the home page
  sound: true, // wooden knock when you go somewhere
  ytProxy: false, // route Theater videos through the proxy
};

export const settings = { ...DEFAULT_SETTINGS, ...load("settings", {}) };
const listeners = new Set();

export function setSetting(key, value) {
  settings[key] = value;
  save("settings", settings);
  listeners.forEach((fn) => fn(key, value));
}

export function onSettingChange(fn) {
  listeners.add(fn);
}

export function resetSettings() {
  Object.assign(settings, DEFAULT_SETTINGS);
  save("settings", settings);
  Object.keys(DEFAULT_SETTINGS).forEach((k) => listeners.forEach((fn) => fn(k, settings[k])));
}

// ---------------------------------------------------------------------------
// Pinned sites + history
// ---------------------------------------------------------------------------

export const DEFAULT_PINS = [
  { name: "YouTube", url: "https://www.youtube.com/" },
  { name: "Google", url: "https://www.google.com/" },
  { name: "Wikipedia", url: "https://en.wikipedia.org/" },
  { name: "Reddit", url: "https://www.reddit.com/" },
  { name: "GitHub", url: "https://github.com/" },
  { name: "Twitch", url: "https://www.twitch.tv/" },
];

export const pins = load("pins", DEFAULT_PINS);
export function savePins() {
  save("pins", pins);
}

export const history = load("history", []); // [{url, title, at}]
export function recordVisit(url, title) {
  if (!url || url.startsWith("tung:")) return;
  const i = history.findIndex((h) => h.url === url);
  if (i !== -1) history.splice(i, 1);
  history.unshift({ url, title: title || "", at: Date.now() });
  history.length = Math.min(history.length, 60);
  save("history", history);
}
export function updateVisitTitle(url, title) {
  const h = history.find((x) => x.url === url);
  if (h && title && h.title !== title) {
    h.title = title;
    save("history", history);
  }
}
export function clearHistory() {
  history.length = 0;
  save("history", history);
}

// ---------------------------------------------------------------------------
// Input → URL
// ---------------------------------------------------------------------------

/** Turn whatever someone typed into a URL: a real address, or a search. */
export function toUrl(input) {
  const text = String(input || "").trim();
  if (!text) return null;
  try {
    const u = new URL(text);
    if (u.protocol === "http:" || u.protocol === "https:") return u.href;
  } catch {
    /* not a full URL */
  }
  if (!/\s/.test(text)) {
    try {
      const u = new URL("https://" + text);
      const host = u.hostname;
      const looksLikeHost =
        (host.includes(".") && !host.endsWith(".") && /\.[a-z]{2,}$/i.test(host)) ||
        /^\d{1,3}(\.\d{1,3}){3}$/.test(host) ||
        host === "localhost";
      if (looksLikeHost) return u.href;
    } catch {
      /* fall through to search */
    }
  }
  const engine = SEARCH_ENGINES[settings.search] || SEARCH_ENGINES.duckduckgo;
  return engine.url.replace("%s", encodeURIComponent(text));
}

export function prettyHost(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return url;
  }
}
