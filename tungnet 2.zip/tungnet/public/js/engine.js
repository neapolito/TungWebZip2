// The proxy engine: registers Ultraviolet's service worker and connects it to
// the server's Wisp socket through bare-mux.

import { settings } from "./store.js";

const SW_URL = "/uv/sw.js";
const listeners = new Set();
let connection = null;

export const engine = {
  state: "starting", // "starting" | "ready" | "error"
  transport: null,
  error: null, // { title, detail }
};

function setState(state, error = null) {
  engine.state = state;
  engine.error = error;
  listeners.forEach((fn) => fn(engine));
}

export function onEngineChange(fn) {
  listeners.add(fn);
  fn(engine);
}

export function wispUrl() {
  return (location.protocol === "https:" ? "wss://" : "ws://") + location.host + "/wisp/";
}

const TRANSPORTS = {
  epoxy: { path: "/epoxy/index.mjs", options: () => ({ wisp: wispUrl() }) },
  libcurl: { path: "/libcurl/index.mjs", options: () => ({ websocket: wispUrl() }) },
};

function config() {
  return self.__uv$config;
}

/** Real URL → the address the proxied frame loads. */
export function encode(url) {
  const c = config();
  return c.prefix + c.encodeUrl(url);
}

/** Frame address (absolute or path) → the real URL, or null if it isn't proxied. */
export function decode(href) {
  const c = config();
  if (!c || !href) return null;
  let rest = null;
  const full = location.origin + c.prefix;
  if (href.startsWith(full)) rest = href.slice(full.length);
  else if (href.startsWith(c.prefix)) rest = href.slice(c.prefix.length);
  if (rest == null) return null;
  let hash = "";
  const hashAt = rest.indexOf("#");
  if (hashAt !== -1) {
    hash = rest.slice(hashAt);
    rest = rest.slice(0, hashAt);
  }
  try {
    const real = c.decodeUrl(rest);
    return real ? real + hash : null;
  } catch {
    return null;
  }
}

export function isProxied(href) {
  const c = config();
  return Boolean(c && href && (href.startsWith(location.origin + c.prefix) || href.startsWith(c.prefix)));
}

async function waitForActive(registration, timeoutMs = 8000) {
  if (registration.active) return;
  const worker = registration.installing || registration.waiting;
  if (!worker) return;
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("The service worker took too long to start.")), timeoutMs);
    const check = () => {
      if (worker.state === "activated") {
        clearTimeout(timer);
        resolve();
      } else if (worker.state === "redundant") {
        clearTimeout(timer);
        reject(new Error("The service worker was replaced while starting."));
      }
    };
    worker.addEventListener("statechange", check);
    check();
  });
}

export async function setTransport(name = settings.engine) {
  const t = TRANSPORTS[name] || TRANSPORTS.epoxy;
  if (!connection) connection = new self.BareMux.BareMuxConnection("/baremux/worker.js");
  await connection.setTransport(t.path, [t.options()]);
  engine.transport = name in TRANSPORTS ? name : "epoxy";
}

export async function startEngine() {
  setState("starting");
  try {
    if (!config() || !self.BareMux || !self.Ultraviolet) {
      throw Object.assign(new Error("engine-files"), {
        title: "Engine files didn't load",
        detail: "Run npm install in the project folder, then restart with npm start.",
      });
    }
    if (!("serviceWorker" in navigator)) {
      const insecure = location.protocol !== "https:" && !["localhost", "127.0.0.1"].includes(location.hostname);
      throw Object.assign(new Error("no-sw"), insecure
        ? {
            title: "TungNet needs HTTPS",
            detail: "Open it from the Codespaces forwarded link (https://…app.github.dev) or from localhost.",
          }
        : {
            title: "This browser blocks service workers",
            detail: "Private or incognito windows in some browsers do this. Try a normal window.",
          });
    }
    const registration = await navigator.serviceWorker.register(SW_URL, { scope: config().prefix.replace(/service\/$/, "") });
    await waitForActive(registration);
    try {
      await setTransport(settings.engine);
    } catch (err) {
      if (settings.engine !== "epoxy") {
        console.warn("[TungNet] transport failed, falling back to epoxy", err);
        await setTransport("epoxy");
      } else {
        throw err;
      }
    }
    setState("ready");
  } catch (err) {
    console.error("[TungNet] engine failed to start", err);
    setState("error", {
      title: err.title || "The proxy engine didn't start",
      detail: err.detail || String(err.message || err),
    });
  }
  return engine;
}

/** Wait until the engine is ready (or failed). */
export function engineSettled() {
  if (engine.state !== "starting") return Promise.resolve(engine);
  return new Promise((resolve) => {
    const fn = (e) => {
      if (e.state !== "starting") {
        listeners.delete(fn);
        resolve(e);
      }
    };
    listeners.add(fn);
  });
}
