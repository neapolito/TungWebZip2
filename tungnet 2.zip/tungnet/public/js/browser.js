// The in-page browser: tabs, address bar, and the frames that show proxied pages.
// Each tab keeps its own back/forward list, so one tab never moves another.

import { encode, decode, engineSettled } from "./engine.js";
import { toUrl, prettyHost, recordVisit, updateVisitTitle, pins, savePins } from "./store.js";
import { stamp, toast } from "./tung.js";
import { attachSuggest } from "./suggest.js";

export const HOME = "tung:home";

const tabs = [];
let activeId = null;
let seq = 0;
let lastStripSig = "";
const hooks = { showBrowse: () => {}, onTabChange: () => {} };

const $ = (id) => document.getElementById(id);
const els = {};

// ---------------------------------------------------------------------------
// Tabs
// ---------------------------------------------------------------------------

export function activeTab() {
  return tabs.find((t) => t.id === activeId) || null;
}

export function createTab(url = HOME, { activate = true } = {}) {
  const tab = {
    id: ++seq,
    url: HOME,
    title: "New tab",
    frame: null,
    loading: false,
    pending: null,
    history: [],
    index: -1,
  };
  tabs.push(tab);
  if (activate) activeId = tab.id;
  if (url && url !== HOME) {
    navigateTab(tab, url);
  } else {
    tab.history = [HOME];
    tab.index = 0;
    render();
  }
  return tab;
}

export function closeTab(id) {
  const i = tabs.findIndex((t) => t.id === id);
  if (i === -1) return;
  const [tab] = tabs.splice(i, 1);
  tab.frame?.remove();
  if (!tabs.length) {
    createTab(HOME);
    return;
  }
  if (activeId === id) activeId = (tabs[i] || tabs[i - 1]).id;
  render();
}

export function activateTab(id) {
  if (!tabs.some((t) => t.id === id)) return;
  activeId = id;
  render();
}

function makeFrame(tab, src) {
  const frame = document.createElement("iframe");
  frame.className = "page-frame";
  frame.title = "Web page";
  frame.setAttribute(
    "allow",
    "fullscreen; autoplay; clipboard-read; clipboard-write; encrypted-media; picture-in-picture; geolocation; microphone; camera; gamepad",
  );
  frame.allowFullscreen = true;
  frame.src = src; // set before inserting so there's no about:blank detour
  frame.addEventListener("load", () => onFrameLoad(tab));
  els.viewport.append(frame);
  tab.frame = frame;
}

export function navigateTab(tab, url, { record = true } = {}) {
  if (url === HOME) return showHome(tab, { record });
  if (record) {
    tab.history.splice(tab.index + 1);
    tab.history.push(url);
    tab.index = tab.history.length - 1;
  }
  tab.url = url;
  tab.pending = url;
  tab.loading = true;
  tab.title = prettyHost(url);
  const target = encode(url);
  if (!tab.frame) {
    makeFrame(tab, target);
  } else {
    try {
      // replace() keeps the page's own history clean; TungNet tracks it per tab
      tab.frame.contentWindow.location.replace(target);
    } catch {
      tab.frame.src = target;
    }
  }
  render();
}

function showHome(tab, { record = true } = {}) {
  if (record) {
    tab.history.splice(tab.index + 1);
    tab.history.push(HOME);
    tab.index = tab.history.length - 1;
  }
  tab.frame?.remove(); // stops any audio/video that was playing
  tab.frame = null;
  tab.url = HOME;
  tab.title = "New tab";
  tab.loading = false;
  tab.pending = null;
  render();
}

// ---------------------------------------------------------------------------
// Navigation API used by the rest of the app
// ---------------------------------------------------------------------------

/** Go somewhere from typed input (a URL or a search) in the active tab. */
export async function go(input, anchor, { newTab = false } = {}) {
  const url = toUrl(input);
  if (!url) return;
  hooks.showBrowse();
  stamp(anchor);
  let tab = activeTab();
  if (newTab || !tab) tab = createTab(HOME);
  tab.loading = true;
  tab.title = prettyHost(url);
  render();
  const engine = await engineSettled();
  if (engine.state === "error") {
    tab.loading = false;
    if (tab.url === HOME) tab.title = "New tab";
    else sync(tab, { committed: true });
    render();
    toast(`${engine.error.title}. ${engine.error.detail}`);
    return;
  }
  navigateTab(tab, url);
}

/** Open a real URL in a fresh in-page tab. */
export async function openInNewTab(url, { activate = true } = {}) {
  hooks.showBrowse();
  await engineSettled();
  return createTab(url, { activate });
}

export function back() {
  const tab = activeTab();
  if (!tab || tab.index <= 0) return;
  tab.index -= 1;
  navigateTab(tab, tab.history[tab.index], { record: false });
}

export function forward() {
  const tab = activeTab();
  if (!tab || tab.index >= tab.history.length - 1) return;
  tab.index += 1;
  navigateTab(tab, tab.history[tab.index], { record: false });
}

export function reload() {
  const tab = activeTab();
  if (!tab?.frame) return;
  tab.loading = true;
  try {
    tab.frame.contentWindow.location.reload();
  } catch {
    tab.frame.src = encode(tab.url);
  }
  render();
}

export function goHome() {
  const tab = activeTab();
  if (tab && tab.url !== HOME) showHome(tab);
}

// ---------------------------------------------------------------------------
// Keeping the UI in sync with what the frame is actually showing
// ---------------------------------------------------------------------------

function frameHref(tab) {
  try {
    return tab.frame?.contentWindow?.location?.href || null;
  } catch {
    return null;
  }
}

function frameTitle(tab) {
  try {
    return tab.frame?.contentDocument?.title?.trim() || "";
  } catch {
    return "";
  }
}

function sync(tab, { committed = false } = {}) {
  if (!tab.frame) return false;
  const href = frameHref(tab);
  if (!href || href === "about:blank") return false;
  const real = decode(href);
  let changed = false;
  // While our own navigation is in flight the old page is still showing; only
  // trust the frame's address once the new page has loaded.
  if (real && real !== tab.url && (committed || !tab.pending)) {
    if (tab.pending) {
      tab.history[tab.index] = real; // our navigation ended up somewhere else (redirect)
    } else {
      tab.history.splice(tab.index + 1); // the page navigated by itself (link, script)
      tab.history.push(real);
      tab.index = tab.history.length - 1;
    }
    tab.url = real;
    changed = true;
  }
  if (!tab.pending || committed) {
    const title = frameTitle(tab) || prettyHost(tab.url);
    if (title !== tab.title) {
      tab.title = title;
      updateVisitTitle(tab.url, title);
      changed = true;
    }
  }
  return changed;
}

function onFrameLoad(tab) {
  if (!tab.frame || frameHref(tab) === "about:blank") return;
  sync(tab, { committed: true });
  tab.pending = null;
  tab.loading = false;
  patchFrame(tab);
  recordVisit(tab.url, tab.title);
  render();
}

/** The page's real URL for something the page handed us (link, window.open). */
function resolveReal(value, tab) {
  if (value == null) return null;
  const s = String(value).trim();
  if (!s || /^(javascript|about|data|blob|mailto|tel|sms):/i.test(s)) return null;
  const decoded = decode(s);
  if (decoded) return decoded;
  const base = tab.url && tab.url !== HOME ? tab.url : undefined;
  try {
    const abs = new URL(s, base || location.href);
    if (abs.origin === location.origin) {
      return base ? new URL(abs.pathname + abs.search + abs.hash, base).href : null;
    }
    if (abs.protocol === "http:" || abs.protocol === "https:") return abs.href;
  } catch {
    /* not a URL */
  }
  return null;
}

/** Keep links and pop-ups inside TungNet instead of real browser tabs. */
function patchFrame(tab) {
  let win, doc;
  try {
    win = tab.frame?.contentWindow;
    doc = win?.document;
  } catch {
    return;
  }
  if (!win || !doc || win.__tungnet) return;
  try {
    win.__tungnet = true;
  } catch {
    return;
  }

  try {
    win.open = function (url) {
      const real = resolveReal(url, tab);
      if (!real) return null;
      const t = createTab(real, { activate: true });
      return t.frame?.contentWindow ?? null;
    };
  } catch {
    /* some pages lock window.open; links are still handled below */
  }

  const handleLink = (e, middle = false) => {
    const a = e.target?.closest?.("a[href]");
    if (!a) return;
    const target = (a.getAttribute("target") || "").toLowerCase();
    const background = middle || e.ctrlKey || e.metaKey;
    const wantsNew = background || e.shiftKey || (target && !["_self", "_top", "_parent"].includes(target));
    const breaksOut = target === "_top" || target === "_parent";
    if (!wantsNew && !breaksOut) return;
    const real = resolveReal(a.href, tab);
    if (!real) return;
    e.preventDefault();
    if (breaksOut && !wantsNew) navigateTab(tab, real);
    else {
      createTab(real, { activate: !background });
      if (background) toast("Opened in a background tab");
    }
  };

  doc.addEventListener("click", (e) => handleLink(e), true);
  doc.addEventListener("auxclick", (e) => e.button === 1 && handleLink(e, true), true);
  doc.addEventListener("keydown", (e) => shortcut(e), true);
  win.addEventListener("beforeunload", () => {
    tab.loading = true;
    render();
  });
}

// Poll the frames: catches in-page navigation (single-page apps) and title changes.
function poll() {
  let changed = false;
  for (const tab of tabs) {
    if (!tab.frame) continue;
    if (sync(tab)) changed = true;
    patchFrame(tab);
  }
  if (changed) render();
}

// ---------------------------------------------------------------------------
// Rendering
// ---------------------------------------------------------------------------

function tokenLetter(tab) {
  if (tab.url === HOME) return "";
  const host = prettyHost(tab.url);
  return (host.match(/[a-z0-9]/i)?.[0] || "?").toUpperCase();
}

function renderStrip() {
  const sig = tabs.map((t) => [t.id, t.title, t.loading, t.url === HOME, t.id === activeId].join("|")).join("~");
  if (sig === lastStripSig) return;
  lastStripSig = sig;
  const frag = document.createDocumentFragment();
  for (const tab of tabs) {
    const el = document.createElement("div");
    el.className = "tab";
    el.dataset.id = tab.id;
    el.setAttribute("role", "tab");
    el.setAttribute("aria-selected", String(tab.id === activeId));
    el.tabIndex = tab.id === activeId ? 0 : -1;
    el.title = tab.url === HOME ? "New tab" : `${tab.title}\n${tab.url}`;
    const icon = document.createElement("span");
    icon.className = "tab-icon";
    if (tab.loading || tab.url === HOME) {
      icon.classList.add("face");
      if (tab.loading) icon.classList.add("spinning");
    } else {
      icon.textContent = tokenLetter(tab);
    }
    const label = document.createElement("span");
    label.className = "tab-title";
    label.textContent = tab.title;
    const close = document.createElement("button");
    close.className = "tab-close";
    close.type = "button";
    close.setAttribute("aria-label", `Close ${tab.title}`);
    close.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-x"/></svg>';
    el.append(icon, label, close);
    frag.append(el);
  }
  els.strip.replaceChildren(frag);
  els.strip.querySelector('[aria-selected="true"]')?.scrollIntoView({ block: "nearest", inline: "nearest" });
}

function render() {
  renderStrip();
  const tab = activeTab();
  for (const t of tabs) t.frame?.classList.toggle("is-active", t === tab && t.url !== HOME);
  const atHome = !tab || tab.url === HOME;
  els.home.hidden = !atHome;
  els.viewport.classList.toggle("at-home", atHome);

  if (document.activeElement !== els.address) {
    els.address.value = atHome ? "" : tab.url;
  }
  els.lock.classList.toggle("secure", !atHome && tab.url.startsWith("https:"));
  els.back.disabled = !tab || tab.index <= 0;
  els.forward.disabled = !tab || tab.index >= tab.history.length - 1;
  els.reload.disabled = atHome;
  const pinned = !atHome && pins.some((p) => sameSite(p.url, tab.url));
  els.star.disabled = atHome;
  els.star.setAttribute("aria-pressed", String(pinned));
  els.star.title = pinned ? "Unpin this page" : "Pin this page to the home screen";

  const loading = Boolean(tab?.loading);
  if (loading) {
    els.loadbar.classList.remove("done");
    els.loadbar.classList.add("loading");
  } else if (els.loadbar.classList.contains("loading")) {
    els.loadbar.classList.remove("loading");
    els.loadbar.classList.add("done");
  }
  hooks.onTabChange(tab);
}

function sameSite(a, b) {
  try {
    const x = new URL(a);
    const y = new URL(b);
    return x.host === y.host && x.pathname.replace(/\/$/, "") === y.pathname.replace(/\/$/, "");
  } catch {
    return a === b;
  }
}

function toggleStar() {
  const tab = activeTab();
  if (!tab || tab.url === HOME) return;
  const i = pins.findIndex((p) => sameSite(p.url, tab.url));
  if (i !== -1) {
    const [gone] = pins.splice(i, 1);
    toast(`Unpinned ${gone.name}`);
  } else {
    const name = (tab.title || prettyHost(tab.url)).slice(0, 40);
    pins.push({ name, url: tab.url });
    toast(`Pinned ${name} to the home screen`);
  }
  savePins();
  render();
  document.dispatchEvent(new CustomEvent("tungnet:pins"));
}

// ---------------------------------------------------------------------------
// Keyboard shortcuts (work inside proxied pages too)
// ---------------------------------------------------------------------------

export function shortcut(e) {
  if (!e.altKey || e.ctrlKey || e.metaKey) return false;
  const key = e.key.toLowerCase();
  if (key === "t") {
    e.preventDefault();
    hooks.showBrowse();
    createTab(HOME);
    els.address.focus();
    return true;
  }
  if (key === "w") {
    e.preventDefault();
    if (activeId != null) closeTab(activeId);
    return true;
  }
  if (key === "l") {
    e.preventDefault();
    hooks.showBrowse();
    els.address.focus();
    els.address.select();
    return true;
  }
  return false;
}

// ---------------------------------------------------------------------------
// Setup
// ---------------------------------------------------------------------------

export function initBrowser({ showBrowse, onTabChange } = {}) {
  if (showBrowse) hooks.showBrowse = showBrowse;
  if (onTabChange) hooks.onTabChange = onTabChange;
  Object.assign(els, {
    strip: $("tabstrip"),
    newTab: $("new-tab"),
    back: $("nav-back"),
    forward: $("nav-forward"),
    reload: $("nav-reload"),
    home: $("home"),
    homeBtn: $("nav-home"),
    form: $("address-form"),
    address: $("address"),
    lock: $("address-lock"),
    star: $("nav-star"),
    fullscreen: $("nav-fullscreen"),
    viewport: $("viewport"),
    loadbar: $("loadbar"),
  });

  els.strip.addEventListener("click", (e) => {
    const tabEl = e.target.closest(".tab");
    if (!tabEl) return;
    const id = Number(tabEl.dataset.id);
    if (e.target.closest(".tab-close")) closeTab(id);
    else activateTab(id);
  });
  els.strip.addEventListener("auxclick", (e) => {
    const tabEl = e.target.closest(".tab");
    if (tabEl && e.button === 1) closeTab(Number(tabEl.dataset.id));
  });
  els.strip.addEventListener("keydown", (e) => {
    if (!["ArrowLeft", "ArrowRight", "Delete"].includes(e.key)) return;
    const i = tabs.findIndex((t) => t.id === activeId);
    if (e.key === "Delete") return closeTab(activeId);
    const next = tabs[(i + (e.key === "ArrowRight" ? 1 : -1) + tabs.length) % tabs.length];
    activateTab(next.id);
    els.strip.querySelector('[aria-selected="true"]')?.focus();
  });
  els.newTab.addEventListener("click", () => {
    createTab(HOME);
    els.address.focus();
  });
  els.back.addEventListener("click", back);
  els.forward.addEventListener("click", forward);
  els.reload.addEventListener("click", reload);
  els.homeBtn.addEventListener("click", goHome);
  els.star.addEventListener("click", toggleStar);
  els.fullscreen.addEventListener("click", () => {
    if (document.fullscreenElement) document.exitFullscreen();
    else els.viewport.requestFullscreen?.().catch(() => toast("Fullscreen isn't allowed here."));
  });

  els.form.addEventListener("submit", (e) => {
    e.preventDefault();
    const value = els.address.value;
    els.address.blur();
    go(value, els.address);
  });
  els.address.addEventListener("focus", () => els.address.select());
  attachSuggest(els.address, {
    onPick: (item) => {
      els.address.blur();
      go(item.type === "history" ? item.url : item.text, els.address);
    },
  });

  document.addEventListener("keydown", shortcut);
  setInterval(poll, 400);
  createTab(HOME);
}
