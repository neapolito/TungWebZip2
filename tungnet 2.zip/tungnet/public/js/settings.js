// Settings view.

import {
  settings,
  setSetting,
  onSettingChange,
  resetSettings,
  clearHistory,
  history,
  pins,
  savePins,
  DEFAULT_PINS,
  clear,
} from "./store.js";
import { engine, onEngineChange, setTransport, startEngine } from "./engine.js";
import { toast } from "./tung.js";

const $ = (id) => document.getElementById(id);

function bindRadios(name, key, onChange) {
  const inputs = document.querySelectorAll(`input[name="${name}"]`);
  const sync = () => inputs.forEach((i) => (i.checked = i.value === settings[key]));
  sync();
  inputs.forEach((input) =>
    input.addEventListener("change", () => {
      if (!input.checked) return;
      const prev = settings[key];
      setSetting(key, input.value);
      onChange?.(input.value, prev);
    }),
  );
  onSettingChange((k) => k === key && sync());
}

function bindCheckbox(id, key) {
  const input = $(id);
  input.checked = Boolean(settings[key]);
  input.addEventListener("change", () => setSetting(key, input.checked));
  onSettingChange((k, v) => k === key && (input.checked = Boolean(v)));
}

function renderCounts() {
  $("history-count").textContent = history.length
    ? `${history.length} page${history.length === 1 ? "" : "s"} remembered for address bar suggestions.`
    : "No pages remembered yet.";
}

export function initSettings() {
  bindRadios("search", "search");
  bindRadios("engine", "engine", async (name, prev) => {
    if (engine.state !== "ready") return; // applied when the engine starts
    try {
      await setTransport(name);
      toast(name === "libcurl" ? "Switched to the libcurl connection" : "Switched to the Epoxy connection");
    } catch (err) {
      console.error(err);
      setSetting("engine", prev);
      toast("That connection couldn't start, so TungNet kept the old one.");
    }
  });
  bindCheckbox("set-quips", "quips");
  bindCheckbox("set-sound", "sound");
  bindCheckbox("set-ytproxy", "ytProxy");

  $("clear-history").addEventListener("click", () => {
    clearHistory();
    renderCounts();
    toast("History cleared");
  });
  $("reset-pins").addEventListener("click", () => {
    pins.splice(0, pins.length, ...structuredClone(DEFAULT_PINS));
    savePins();
    document.dispatchEvent(new CustomEvent("tungnet:pins"));
    toast("Pinned sites reset");
  });
  $("reset-all").addEventListener("click", () => {
    clearHistory();
    clear("yt.recent");
    pins.splice(0, pins.length, ...structuredClone(DEFAULT_PINS));
    savePins();
    resetSettings();
    document.dispatchEvent(new CustomEvent("tungnet:pins"));
    renderCounts();
    toast("TungNet is back to how it started");
  });
  $("engine-retry").addEventListener("click", () => startEngine());

  onEngineChange((e) => {
    const text = $("engine-state");
    if (e.state === "ready") {
      text.textContent = `Running on the ${e.transport === "libcurl" ? "libcurl" : "Epoxy"} connection.`;
    } else if (e.state === "starting") {
      text.textContent = "Starting…";
    } else {
      text.textContent = `${e.error.title}. ${e.error.detail}`;
    }
    $("engine-retry").hidden = e.state !== "error";
  });

  fetch("/api/health")
    .then((r) => r.json())
    .then((h) => {
      $("about-version").textContent = `TungNet ${h.version}, Node ${h.node}`;
      if (!h.engines?.libcurl) {
        const input = document.querySelector('input[name="engine"][value="libcurl"]');
        input.disabled = true;
        input.closest("label").title = "Not installed on this server";
      }
      $("lock-group").hidden = !h.locked;
    })
    .catch(() => {
      $("about-version").textContent = "Couldn't reach the TungNet server.";
    });

  $("lock-now").addEventListener("click", async () => {
    try {
      await fetch("/api/lock", { method: "POST" });
    } catch {
      /* lock anyway by sending them to the gate */
    }
    location.replace("/gate.html");
  });

  document.addEventListener("tungnet:view", (e) => e.detail === "settings" && renderCounts());
  renderCounts();
}
