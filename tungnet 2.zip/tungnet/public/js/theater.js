// Tung's Theater: paste a YouTube link, it plays right here.

import { settings, setSetting, onSettingChange, load, save } from "./store.js";
import { encode, engineSettled } from "./engine.js";
import { openInNewTab } from "./browser.js";
import { toast, stamp, wobble } from "./tung.js";

const ID = /^[A-Za-z0-9_-]{11}$/;
const $ = (id) => document.getElementById(id);

let current = null; // { id, list, start, title, channel }
let player = null;
let endedFor = null;
const queue = [];
const recent = load("yt.recent", []);
const els = {};

// ---------------------------------------------------------------------------
// Link parsing
// ---------------------------------------------------------------------------

function parseTime(t) {
  if (!t) return 0;
  if (/^\d+$/.test(t)) return Number(t);
  const m = String(t).match(/^(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s?)?$/);
  if (!m) return 0;
  return (Number(m[1]) || 0) * 3600 + (Number(m[2]) || 0) * 60 + (Number(m[3]) || 0);
}

/** Understands watch, youtu.be, shorts, embed, live, playlist links, and bare ids. */
export function parseYouTube(input) {
  let s = String(input || "").trim();
  if (!s) return null;
  if (ID.test(s)) return { id: s, list: null, start: 0 };
  if (!/^https?:\/\//i.test(s)) s = "https://" + s;
  let u;
  try {
    u = new URL(s);
  } catch {
    return null;
  }
  const host = u.hostname.replace(/^(www|m|music)\./, "");
  let id = null;
  if (host === "youtu.be") {
    id = u.pathname.split("/")[1] || null;
  } else if (host === "youtube.com" || host === "youtube-nocookie.com") {
    if (u.pathname === "/watch") id = u.searchParams.get("v");
    else {
      const m = u.pathname.match(/^\/(?:shorts|embed|live|v|e)\/([A-Za-z0-9_-]{11})/);
      if (m) id = m[1];
    }
  } else {
    return null;
  }
  if (id && !ID.test(id)) id = null;
  const list = u.searchParams.get("list");
  if (!id && !list) return null;
  const hashT = u.hash.match(/t=([^&]+)/)?.[1];
  const start = parseTime(u.searchParams.get("t") || u.searchParams.get("start") || hashT);
  return { id, list: list || null, start };
}

function embedUrl(item) {
  const p = new URLSearchParams({
    autoplay: "1",
    rel: "0",
    playsinline: "1",
    enablejsapi: "1",
    iv_load_policy: "3",
  });
  // Origin lets the player talk back to us for queue auto-advance.
  p.set("origin", location.origin);
  if (item.start) p.set("start", String(item.start));
  if (item.list) p.set("list", item.list);
  // Always the privacy-friendly host; it's also the most reliable for embeds.
  return `https://www.youtube-nocookie.com/embed/${item.id || "videoseries"}?${p}`;
}

function watchUrl(item) {
  if (!item.id) return `https://www.youtube.com/playlist?list=${item.list}`;
  let url = `https://www.youtube.com/watch?v=${item.id}`;
  if (item.list) url += `&list=${item.list}`;
  if (item.start) url += `&t=${item.start}s`;
  return url;
}

const thumb = (item) => (item.id ? `/api/yt/thumb/${item.id}` : "/img/tung-face.png");
const label = (item) => item.title || (item.id ? `Video ${item.id}` : "Playlist");

async function fillInfo(item) {
  if (!item.id || item.title) return;
  try {
    const r = await fetch(`/api/yt/info?id=${item.id}`);
    const d = await r.json();
    if (d.title) {
      item.title = d.title;
      item.channel = d.channel;
      const saved = recent.find((x) => x.id === item.id && x.list === item.list);
      if (saved) Object.assign(saved, { title: d.title, channel: d.channel });
      save("yt.recent", recent);
      render();
    }
  } catch {
    /* titles are a nice-to-have */
  }
}

// ---------------------------------------------------------------------------
// Playback
// ---------------------------------------------------------------------------

async function play(item) {
  current = { ...item };
  endedFor = null;
  const proxied = settings.ytProxy;
  let src = embedUrl(current);
  if (proxied) {
    const engine = await engineSettled();
    if (engine.state !== "ready") {
      toast("The proxy engine isn't running, so this video plays directly.");
    } else {
      src = encode(src);
    }
  }
  player?.remove();
  player = document.createElement("iframe");
  player.title = "YouTube video player";
  player.allow = "autoplay; encrypted-media; picture-in-picture; fullscreen; clipboard-write";
  player.allowFullscreen = true;
  player.referrerPolicy = "strict-origin-when-cross-origin";
  player.src = src;
  player.addEventListener("load", listen);
  els.stage.append(player);
  els.empty.hidden = true;

  const key = (x) => `${x.id}|${x.list}`;
  const i = recent.findIndex((x) => key(x) === key(current));
  if (i !== -1) {
    current.title ||= recent[i].title;
    current.channel ||= recent[i].channel;
    recent.splice(i, 1);
  }
  recent.unshift({ id: current.id, list: current.list, start: 0, title: current.title || "", channel: current.channel || "" });
  recent.length = Math.min(recent.length, 12);
  save("yt.recent", recent);
  render();
  fillInfo(current);
}

// Ask the embedded player to report its state so the queue can auto-advance.
function listen() {
  const send = () => {
    try {
      player?.contentWindow?.postMessage(JSON.stringify({ event: "listening", id: 1, channel: "widget" }), "*");
    } catch {
      /* ignore */
    }
  };
  send();
  setTimeout(send, 600);
  setTimeout(send, 1800);
}

window.addEventListener("message", (e) => {
  if (!player || e.source !== player.contentWindow) return;
  let data = e.data;
  if (typeof data === "string") {
    try {
      data = JSON.parse(data);
    } catch {
      return;
    }
  }
  if (!data || typeof data !== "object") return;
  const state =
    data.event === "onStateChange" ? data.info : data.event === "infoDelivery" ? data.info?.playerState : undefined;
  if (state === 0 && current && endedFor !== current) {
    endedFor = current;
    if (queue.length) setTimeout(next, 700);
  }
  const t = data.info?.videoData?.title;
  if (t && current && !current.title) {
    current.title = t;
    current.channel = data.info?.videoData?.author || current.channel;
    render();
  }
});

function next() {
  if (!queue.length) return toast("The queue is empty.");
  play(queue.shift());
}

function stop() {
  player?.remove();
  player = null;
  current = null;
  els.empty.hidden = false;
  render();
}

// ---------------------------------------------------------------------------
// Rendering
// ---------------------------------------------------------------------------

function listItem(item, { onPlay, actions }) {
  const li = document.createElement("li");
  li.className = "reel";
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "reel-main";
  const img = document.createElement("img");
  img.src = thumb(item);
  img.alt = "";
  img.loading = "lazy";
  img.onerror = () => {
    img.onerror = null;
    img.src = "/img/tung-face.png";
  };
  const text = document.createElement("span");
  text.className = "reel-text";
  const t = document.createElement("span");
  t.className = "reel-title";
  t.textContent = label(item);
  const c = document.createElement("span");
  c.className = "reel-meta";
  c.textContent = item.channel || (item.list && !item.id ? "Playlist" : "YouTube");
  text.append(t, c);
  btn.append(img, text);
  btn.addEventListener("click", onPlay);
  li.append(btn);
  for (const a of actions) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "icon-btn small";
    b.setAttribute("aria-label", a.label);
    b.title = a.label;
    b.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true"><use href="#${a.icon}"/></svg>`;
    b.addEventListener("click", a.run);
    li.append(b);
  }
  return li;
}

function render() {
  els.nowTitle.textContent = current ? label(current) : "Nothing playing yet";
  els.nowMeta.textContent = current
    ? [current.channel, settings.ytProxy ? "through TungNet" : "direct from YouTube"].filter(Boolean).join(", ")
    : "Paste a YouTube link above to start the show.";
  els.next.disabled = !queue.length;
  els.open.disabled = !current;
  els.stopBtn.disabled = !current;

  els.queueList.replaceChildren(
    ...queue.map((item, i) =>
      listItem(item, {
        onPlay: () => {
          queue.splice(i, 1);
          play(item);
        },
        actions: [{ icon: "i-x", label: "Remove from queue", run: () => (queue.splice(i, 1), render()) }],
      }),
    ),
  );
  els.queueEmpty.hidden = queue.length > 0;
  els.queueCount.textContent = queue.length ? String(queue.length) : "";

  els.recentList.replaceChildren(
    ...recent.map((item) =>
      listItem(item, {
        onPlay: () => play(item),
        actions: [
          {
            icon: "i-queue",
            label: "Add to queue",
            run: () => {
              queue.push({ ...item });
              toast(`Queued: ${label(item)}`);
              render();
            },
          },
        ],
      }),
    ),
  );
  els.recentEmpty.hidden = recent.length > 0;
  els.clearRecent.hidden = recent.length === 0;
}

// ---------------------------------------------------------------------------
// Setup
// ---------------------------------------------------------------------------

export function initTheater() {
  Object.assign(els, {
    view: $("view-theater"),
    form: $("yt-form"),
    input: $("yt-url"),
    addQueue: $("yt-add-queue"),
    proxy: $("yt-proxy"),
    stage: $("yt-stage"),
    empty: $("yt-empty"),
    peek: $("yt-peek"),
    nowTitle: $("yt-now-title"),
    nowMeta: $("yt-now-meta"),
    next: $("yt-next"),
    open: $("yt-open"),
    stopBtn: $("yt-stop"),
    cinema: $("yt-cinema"),
    queueList: $("yt-queue-list"),
    queueEmpty: $("yt-queue-empty"),
    queueCount: $("yt-queue-count"),
    recentList: $("yt-recent-list"),
    recentEmpty: $("yt-recent-empty"),
    clearRecent: $("yt-clear-recent"),
    fallback: $("yt-fallback"),
    error: $("yt-error"),
  });

  const readInput = () => {
    const item = parseYouTube(els.input.value);
    els.error.hidden = Boolean(item);
    if (!item) {
      els.error.textContent =
        "That doesn't look like a YouTube link. Try one like youtube.com/watch?v=… or youtu.be/…";
      els.input.focus();
    }
    return item;
  };

  els.form.addEventListener("submit", (e) => {
    e.preventDefault();
    const item = readInput();
    if (!item) return;
    stamp(els.form.querySelector(".lamp-btn"));
    wobble(els.peek);
    els.input.value = "";
    play(item);
  });
  els.input.addEventListener("input", () => (els.error.hidden = true));

  els.addQueue.addEventListener("click", () => {
    const item = readInput();
    if (!item) return;
    els.input.value = "";
    if (!current) return play(item);
    queue.push(item);
    toast("Added to the queue");
    render();
    fillInfo(item);
  });

  els.proxy.checked = settings.ytProxy;
  els.proxy.addEventListener("change", () => setSetting("ytProxy", els.proxy.checked));
  onSettingChange((key, value) => {
    if (key !== "ytProxy") return;
    els.proxy.checked = value;
    if (current) play(current); // reload the video the new way
  });

  els.next.addEventListener("click", next);
  els.stopBtn.addEventListener("click", stop);
  const openOnYouTube = () => {
    if (!current) {
      toast("Play something first, then you can open it on YouTube.");
      return;
    }
    const url = watchUrl(current);
    stop();
    openInNewTab(url);
    toast("Opened on YouTube in a TungNet tab");
  };
  els.open.addEventListener("click", openOnYouTube);
  els.fallback.addEventListener("click", openOnYouTube);
  els.cinema.addEventListener("click", () => {
    const on = els.view.classList.toggle("cinema");
    els.cinema.setAttribute("aria-pressed", String(on));
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && els.view.classList.contains("cinema")) {
      els.view.classList.remove("cinema");
      els.cinema.setAttribute("aria-pressed", "false");
    }
  });
  els.clearRecent.addEventListener("click", () => {
    recent.length = 0;
    save("yt.recent", recent);
    render();
  });
  els.peek.addEventListener("click", () => wobble(els.peek));

  render();
}

/** Called by other parts of the app (e.g. a pasted YouTube link in the address bar). */
export function playFromLink(link) {
  const item = parseYouTube(link);
  if (item) play(item);
  return Boolean(item);
}
