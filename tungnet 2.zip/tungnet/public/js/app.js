// TungNet: wires the views together.

import { settings, setSetting, onSettingChange, pins, savePins, prettyHost, toUrl } from "./store.js";
import { startEngine, onEngineChange } from "./engine.js";
import { initBrowser, go, HOME } from "./browser.js";
import { initTheater, parseYouTube, playFromLink } from "./theater.js";
import { initArcade } from "./arcade.js";
import { initSettings } from "./settings.js";
import { nextQuip, currentQuip, wobble, knock, reducedMotion, toast } from "./tung.js";
import { attachSuggest } from "./suggest.js";

const $ = (id) => document.getElementById(id);

// ---------------------------------------------------------------------------
// Views
// ---------------------------------------------------------------------------

const VIEWS = ["browse", "theater", "arcade", "settings"];

function showView(name) {
  if (!VIEWS.includes(name)) name = "browse";
  for (const v of VIEWS) {
    $(`view-${v}`).hidden = v !== name;
    const tab = $("view-nav").querySelector(`[data-view="${v}"]`);
    tab.setAttribute("aria-selected", String(v === name));
    tab.tabIndex = v === name ? 0 : -1;
  }
  document.body.dataset.section = name;
  if (location.hash.slice(1) !== name) history.replaceState(null, "", name === "browse" ? location.pathname : `#${name}`);
  document.dispatchEvent(new CustomEvent("tungnet:view", { detail: name }));
}

function initViews() {
  const nav = $("view-nav");
  nav.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-view]");
    if (btn) showView(btn.dataset.view);
  });
  nav.addEventListener("keydown", (e) => {
    if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
    const current = VIEWS.indexOf(document.body.dataset.section);
    const next = VIEWS[(current + (e.key === "ArrowRight" ? 1 : -1) + VIEWS.length) % VIEWS.length];
    showView(next);
    $("view-nav").querySelector(`[data-view="${next}"]`).focus();
  });
  window.addEventListener("hashchange", () => showView(location.hash.slice(1)));
  showView(location.hash.slice(1));
}

// ---------------------------------------------------------------------------
// Home: Tung, the search plank, pinned sites
// ---------------------------------------------------------------------------

const COIN_WOODS = ["#7a4a23", "#93602f", "#5e3519", "#a8743f", "#6b3d1f", "#86532a", "#4f2c14"];

function hashString(s) {
  let h = 0;
  for (const ch of s) h = (h * 31 + ch.charCodeAt(0)) | 0;
  return Math.abs(h);
}

function renderPins() {
  const list = $("pin-list");
  const items = pins.map((pin, i) => {
    const li = document.createElement("li");
    li.className = "pin";
    const a = document.createElement("a");
    a.className = "coin-link";
    a.href = "#";
    a.title = pin.url;
    a.addEventListener("click", (e) => {
      e.preventDefault();
      go(pin.url, a);
    });
    const coin = document.createElement("span");
    coin.className = "coin";
    coin.style.setProperty("--wood", COIN_WOODS[hashString(prettyHost(pin.url)) % COIN_WOODS.length]);
    coin.textContent = (pin.name.match(/[a-z0-9]/i)?.[0] || "?").toUpperCase();
    const name = document.createElement("span");
    name.className = "coin-name";
    name.textContent = pin.name;
    a.append(coin, name);
    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "pin-remove";
    remove.setAttribute("aria-label", `Unpin ${pin.name}`);
    remove.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-x"/></svg>';
    remove.addEventListener("click", () => {
      pins.splice(i, 1);
      savePins();
      renderPins();
      toast(`Unpinned ${pin.name}`);
    });
    li.append(a, remove);
    return li;
  });

  const addLi = document.createElement("li");
  addLi.className = "pin";
  const add = document.createElement("button");
  add.type = "button";
  add.className = "coin-link";
  add.innerHTML =
    '<span class="coin add"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-plus"/></svg></span><span class="coin-name">Pin a site</span>';
  add.addEventListener("click", openPinDialog);
  addLi.append(add);
  list.replaceChildren(...items, addLi);
}

function openPinDialog() {
  const dialog = $("pin-dialog");
  $("pin-form").reset();
  $("pin-error").hidden = true;
  dialog.showModal();
  $("pin-url").focus();
}

function initPinDialog() {
  const dialog = $("pin-dialog");
  $("pin-cancel").addEventListener("click", () => dialog.close());
  $("pin-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const raw = $("pin-url").value.trim();
    const url = toUrl(raw);
    if (!url || !/^https?:/.test(url) || !/[./]/.test(raw)) {
      $("pin-error").hidden = false;
      return;
    }
    const name = $("pin-name").value.trim() || prettyHost(url).replace(/\.[a-z]+$/i, "").replace(/^./, (c) => c.toUpperCase());
    pins.push({ name: name.slice(0, 40), url });
    savePins();
    renderPins();
    dialog.close();
    toast(`Pinned ${name}`);
  });
  document.addEventListener("tungnet:pins", renderPins);
}

function initHome() {
  const form = $("home-form");
  const input = $("home-search");
  const tung = $("home-tung");
  const bubble = $("quip");

  const say = (text) => {
    bubble.textContent = text;
    if (!reducedMotion()) {
      bubble.classList.remove("pop");
      void bubble.offsetWidth;
      bubble.classList.add("pop");
    }
  };
  say(currentQuip());
  bubble.hidden = !settings.quips;
  onSettingChange((k, v) => k === "quips" && (bubble.hidden = !v));

  $("home-tung-btn").addEventListener("click", () => {
    wobble(tung);
    knock(1);
    if (settings.quips) say(nextQuip());
  });

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const value = input.value.trim();
    if (!value) return input.focus();
    input.value = "";
    // A YouTube video link goes straight to the Theater.
    if (/youtu/i.test(value) && parseYouTube(value)) {
      showView("theater");
      playFromLink(value);
      return;
    }
    go(value, form.querySelector(".lamp-btn"));
  });
  attachSuggest(input, {
    onPick: (item) => {
      input.value = "";
      go(item.type === "history" ? item.url : item.text, form.querySelector(".lamp-btn"));
    },
  });

  // "/" jumps to the search box
  document.addEventListener("keydown", (e) => {
    if (e.key !== "/" || e.ctrlKey || e.metaKey || e.altKey) return;
    const tag = document.activeElement?.tagName;
    if (tag === "INPUT" || tag === "TEXTAREA" || document.activeElement?.isContentEditable) return;
    if (document.body.dataset.section === "arcade") return; // don't grab keys mid-game
    e.preventDefault();
    if (document.body.dataset.section === "theater") $("yt-url").focus();
    else {
      showView("browse");
      ($("home").hidden ? $("address") : input).focus();
    }
  });

  const edit = $("pins-edit");
  edit.addEventListener("click", () => {
    const on = edit.closest(".pins").classList.toggle("editing");
    edit.setAttribute("aria-pressed", String(on));
    edit.textContent = on ? "Done" : "Edit";
  });

  renderPins();
  initPinDialog();
}

// ---------------------------------------------------------------------------
// Header: engine lamp + sound toggle
// ---------------------------------------------------------------------------

function initHeader() {
  const pill = $("engine-pill");
  const label = pill.querySelector(".pill-label");
  onEngineChange((e) => {
    pill.dataset.state = e.state;
    if (e.state === "ready") {
      label.textContent = "Lamp on";
      pill.title = "The proxy engine is running";
    } else if (e.state === "starting") {
      label.textContent = "Lighting";
      pill.title = "The proxy engine is starting";
    } else {
      label.textContent = "Lamp out";
      pill.title = `${e.error.title}. ${e.error.detail}`;
    }
    const banner = $("engine-banner");
    banner.hidden = e.state !== "error";
    if (e.state === "error") {
      $("engine-banner-title").textContent = e.error.title;
      $("engine-banner-detail").textContent = e.error.detail;
    }
  });
  pill.addEventListener("click", () => showView("settings"));
  $("engine-banner-retry").addEventListener("click", () => startEngine());

  const sound = $("sound-toggle");
  const syncSound = () => {
    sound.setAttribute("aria-pressed", String(settings.sound));
    sound.setAttribute("aria-label", settings.sound ? "Mute Tung's knocks" : "Unmute Tung's knocks");
    sound.title = sound.getAttribute("aria-label");
    sound.querySelector("use").setAttribute("href", settings.sound ? "#i-sound" : "#i-mute");
  };
  syncSound();
  sound.addEventListener("click", () => {
    setSetting("sound", !settings.sound);
    if (settings.sound) knock(1);
  });
  onSettingChange((k) => k === "sound" && syncSound());
}

// ---------------------------------------------------------------------------
// Splash: shown once per visit while the engine lights up
// ---------------------------------------------------------------------------

async function runSplash(enginePromise) {
  const splash = $("splash");
  let seen = false;
  try {
    seen = sessionStorage.getItem("tungnet.splash") === "1";
    sessionStorage.setItem("tungnet.splash", "1");
  } catch {
    /* ignore */
  }
  if (seen || reducedMotion()) {
    splash.remove();
    document.body.classList.add("ready");
    return;
  }
  const minimum = new Promise((r) => setTimeout(r, 1400));
  const maximum = new Promise((r) => setTimeout(r, 3800));
  await Promise.race([Promise.all([minimum, enginePromise]), maximum]);
  splash.classList.add("leaving");
  document.body.classList.add("ready");
  setTimeout(() => splash.remove(), 600);
}

// ---------------------------------------------------------------------------
// Boot
// ---------------------------------------------------------------------------

initViews();
initHeader();
initBrowser({
  showBrowse: () => showView("browse"),
  onTabChange: (tab) => {
    document.title = !tab || tab.url === HOME ? "TungNet" : `${tab.title} – TungNet`;
  },
});
initHome();
initTheater();
initArcade();
initSettings();

runSplash(startEngine());
