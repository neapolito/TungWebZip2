// Classic Snake, TungNet style. Eat the lamps, don't bite yourself.

import { makeStage, Loop, Keys, Pointer, Sfx, C, randInt, roundRect } from "./engine.js";

export default {
  id: "snake",
  name: "Timber Snake",
  blurb: "Guide the snake, eat the glowing lamps, and grow as long as you can.",
  tag: "Classic",
  controls: "Turn: arrows / W A S D / swipe",
  emoji: "🐍",
  accent: "#d8a53f",

  make(host, api) {
    const stage = makeStage(host);
    const keys = Keys();

    let state = "ready";
    let cell, cols, rows, ox, oy, snake, dir, nextDir, food, score, tick, acc, speed;

    function grid() {
      const { w, h } = stage;
      cell = Math.max(14, Math.floor(Math.min(w, h) / 20));
      cols = Math.floor(w / cell);
      rows = Math.floor(h / cell);
      ox = Math.floor((w - cols * cell) / 2);
      oy = Math.floor((h - rows * cell) / 2);
    }
    grid();

    function placeFood() {
      let p;
      do {
        p = { x: randInt(0, cols - 1), y: randInt(0, rows - 1) };
      } while (snake.some((s) => s.x === p.x && s.y === p.y));
      food = p;
    }

    function reset() {
      grid();
      const cx = Math.floor(cols / 2);
      const cy = Math.floor(rows / 2);
      snake = [
        { x: cx, y: cy },
        { x: cx - 1, y: cy },
        { x: cx - 2, y: cy },
      ];
      dir = { x: 1, y: 0 };
      nextDir = dir;
      score = 0;
      speed = 8;
      acc = 0;
      placeFood();
    }
    reset();

    function start() {
      reset();
      state = "playing";
      api.setScore(0);
      Sfx.pick();
    }

    function turn(x, y) {
      if (x === -dir.x && y === -dir.y) return; // no reversing
      nextDir = { x, y };
    }
    keys.onLeft(() => turn(-1, 0));
    keys.onRight(() => turn(1, 0));
    keys.onUp(() => turn(0, -1));
    keys.onDown(() => turn(0, 1));
    keys.onAction(() => {
      if (state !== "playing") start();
    });

    function step() {
      dir = nextDir;
      const head = { x: snake[0].x + dir.x, y: snake[0].y + dir.y };
      if (head.x < 0 || head.y < 0 || head.x >= cols || head.y >= rows || snake.some((s) => s.x === head.x && s.y === head.y)) {
        state = "over";
        Sfx.over();
        api.gameOver(score);
        return;
      }
      snake.unshift(head);
      if (head.x === food.x && head.y === food.y) {
        score += 10;
        api.setScore(score);
        speed = Math.min(20, speed + 0.4);
        Sfx.score();
        placeFood();
      } else {
        snake.pop();
      }
    }

    function update(dt) {
      if (state !== "playing") return;
      acc += dt;
      const interval = 1 / speed;
      while (acc >= interval) {
        acc -= interval;
        step();
        if (state !== "playing") break;
      }
    }

    function cellRect(ctx, gx, gy, pad, color, r) {
      roundRect(ctx, ox + gx * cell + pad, oy + gy * cell + pad, cell - pad * 2, cell - pad * 2, r ?? cell * 0.28);
      ctx.fillStyle = color;
      ctx.fill();
    }

    function draw() {
      const { ctx, w, h } = stage;
      ctx.fillStyle = C.bark;
      ctx.fillRect(0, 0, w, h);
      // board
      ctx.fillStyle = "rgba(0,0,0,0.25)";
      ctx.fillRect(ox, oy, cols * cell, rows * cell);
      ctx.strokeStyle = "rgba(255,220,170,0.08)";
      ctx.lineWidth = 1;
      for (let i = 0; i <= cols; i++) {
        ctx.beginPath();
        ctx.moveTo(ox + i * cell, oy);
        ctx.lineTo(ox + i * cell, oy + rows * cell);
        ctx.stroke();
      }
      for (let j = 0; j <= rows; j++) {
        ctx.beginPath();
        ctx.moveTo(ox, oy + j * cell);
        ctx.lineTo(ox + cols * cell, oy + j * cell);
        ctx.stroke();
      }
      // food (glowing lamp)
      ctx.save();
      ctx.shadowColor = C.lamp;
      ctx.shadowBlur = 16;
      cellRect(ctx, food.x, food.y, cell * 0.2, C.lamp, cell * 0.3);
      ctx.restore();
      // snake
      snake.forEach((s, i) => {
        const head = i === 0;
        cellRect(ctx, s.x, s.y, cell * 0.08, head ? C.ember : i % 2 ? C.wood2 : C.wood, cell * 0.3);
        if (head) {
          ctx.fillStyle = C.ink;
          const ex = cell * 0.18;
          const cx = ox + s.x * cell + cell / 2;
          const cy = oy + s.y * cell + cell / 2;
          ctx.beginPath();
          ctx.arc(cx - ex + dir.x * ex * 0.6, cy - ex + dir.y * ex * 0.6, cell * 0.08, 0, 7);
          ctx.arc(cx + ex + dir.x * ex * 0.6, cy - ex + dir.y * ex * 0.6, cell * 0.08, 0, 7);
          ctx.fill();
        }
      });

      ctx.fillStyle = C.cream;
      ctx.font = `700 ${Math.min(20, w * 0.045)}px Rubik, sans-serif`;
      ctx.textAlign = "left";
      ctx.fillText(`Length ${snake.length}`, ox + 4, oy - 8 > 14 ? oy - 8 : 20);

      if (state === "ready") overlay("Timber Snake", "Press Space or tap to start");
      else if (state === "over") overlay("Chomped!", `Score ${score}  ·  best ${api.best()}`, "Space or tap to retry");
    }

    function overlay(title, line, line2) {
      const { ctx, w, h } = stage;
      ctx.fillStyle = "rgba(10,6,3,0.66)";
      ctx.fillRect(0, 0, w, h);
      ctx.textAlign = "center";
      ctx.fillStyle = C.cream;
      ctx.font = `800 ${Math.min(42, w * 0.09)}px Rubik, sans-serif`;
      ctx.fillText(title, w / 2, h * 0.44);
      ctx.fillStyle = C.paper;
      ctx.font = `600 ${Math.min(18, w * 0.044)}px Rubik, sans-serif`;
      ctx.fillText(line, w / 2, h * 0.53);
      if (line2) {
        ctx.fillStyle = C.dust;
        ctx.font = `500 ${Math.min(15, w * 0.038)}px Rubik, sans-serif`;
        ctx.fillText(line2, w / 2, h * 0.6);
      }
    }

    const pointer = Pointer(stage.canvas, {
      swipe: (d) => {
        if (state !== "playing") return start();
        if (d === "left") turn(-1, 0);
        else if (d === "right") turn(1, 0);
        else if (d === "up") turn(0, -1);
        else turn(0, 1);
      },
      tap: () => {
        if (state !== "playing") start();
      },
    });

    stage.onresize = () => {
      if (state === "ready") reset();
      else grid();
    };

    const loop = Loop((dt) => {
      update(dt);
      draw();
    });
    loop.start();

    return {
      destroy() {
        loop.stop();
        keys.destroy();
        pointer.destroy();
        stage.destroy();
      },
      pause: () => loop.stop(),
      resume: () => loop.start(),
    };
  },
};
