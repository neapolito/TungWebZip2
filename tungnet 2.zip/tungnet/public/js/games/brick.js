// Tung Breaker — knock out every plank with the ball.

import { makeStage, Loop, Keys, Pointer, Sfx, C, clamp, roundRect } from "./engine.js";

export default {
  id: "brick",
  name: "Tung Breaker",
  blurb: "Bounce the ball, smash every plank, and keep it off the floor.",
  tag: "Arcade",
  controls: "Move: arrows / A D / mouse / drag · Launch: Space / tap",
  emoji: "🧱",
  accent: "#e5972e",

  make(host, api) {
    const stage = makeStage(host);
    const keys = Keys();

    let state = "ready";
    let paddle, ball, bricks, score, lives, level, stuck, speed;

    function buildBricks() {
      const { w, h } = stage;
      const cols = 8;
      const rows = Math.min(4 + level, 7);
      const pad = w * 0.012;
      const bw = (w * 0.92 - pad * (cols - 1)) / cols;
      const bh = h * 0.035;
      const top = h * 0.1;
      const left = w * 0.04;
      bricks = [];
      const palette = ["#f2a33a", "#e5972e", "#d68a2e", "#c27a2c", "#b06a2c", "#9c6a34", "#8a5a2e"];
      for (let r = 0; r < rows; r++)
        for (let c = 0; c < cols; c++) {
          bricks.push({
            x: left + c * (bw + pad),
            y: top + r * (bh + pad),
            w: bw,
            h: bh,
            color: palette[r % palette.length],
            hp: r < 1 ? 2 : 1,
          });
        }
    }

    function resetBall() {
      const { w, h } = stage;
      paddle = { x: w / 2, y: h * 0.92, w: w * 0.2, h: Math.max(10, h * 0.022) };
      ball = { x: w / 2, y: paddle.y - 14, r: Math.max(7, Math.min(w, h) * 0.018) };
      stuck = true;
    }

    function reset() {
      score = 0;
      lives = 3;
      level = 1;
      speed = Math.min(stage.w, stage.h) * 0.9;
      buildBricks();
      resetBall();
      api.setScore(0);
    }
    reset();

    function launch() {
      if (!stuck) return;
      stuck = false;
      const a = -Math.PI / 2 + (Math.random() * 0.5 - 0.25);
      ball.vx = Math.cos(a) * speed;
      ball.vy = Math.sin(a) * speed;
      Sfx.blip(560);
    }

    function start() {
      if (state === "over" || state === "ready") {
        reset();
        state = "playing";
        Sfx.pick();
      } else {
        launch();
      }
    }
    keys.onAction(start);

    const pointer = Pointer(stage.canvas, {
      down: (x) => {
        if (state !== "playing") return start();
        paddle.x = x;
        if (stuck) launch();
      },
      move: (x, _y, active) => {
        if (active && state === "playing") paddle.x = x;
      },
      tap: () => {
        if (state !== "playing") start();
      },
    });

    function hitBrick(b) {
      // Which side? compare penetration.
      const cx = clamp(ball.x, b.x, b.x + b.w);
      const cy = clamp(ball.y, b.y, b.y + b.h);
      const dx = ball.x - cx;
      const dy = ball.y - cy;
      if (Math.abs(dx) > Math.abs(dy)) ball.vx *= -1;
      else ball.vy *= -1;
      b.hp--;
      score += 10;
      api.setScore(score);
      Sfx.bounce();
    }

    function update(dt) {
      if (state !== "playing") return;
      const { w, h } = stage;
      const pdx = w * 1.3 * dt;
      if (keys.left()) paddle.x -= pdx;
      if (keys.right()) paddle.x += pdx;
      paddle.x = clamp(paddle.x, paddle.w / 2, w - paddle.w / 2);

      if (stuck) {
        ball.x = paddle.x;
        ball.y = paddle.y - ball.r - paddle.h / 2;
        return;
      }

      const steps = 4;
      const sdt = dt / steps;
      for (let s = 0; s < steps; s++) {
        ball.x += ball.vx * sdt;
        ball.y += ball.vy * sdt;
        if (ball.x - ball.r < 0) {
          ball.x = ball.r;
          ball.vx = Math.abs(ball.vx);
          Sfx.bounce();
        }
        if (ball.x + ball.r > w) {
          ball.x = w - ball.r;
          ball.vx = -Math.abs(ball.vx);
          Sfx.bounce();
        }
        if (ball.y - ball.r < 0) {
          ball.y = ball.r;
          ball.vy = Math.abs(ball.vy);
          Sfx.bounce();
        }
        // paddle
        if (
          ball.vy > 0 &&
          ball.y + ball.r >= paddle.y - paddle.h / 2 &&
          ball.y < paddle.y &&
          Math.abs(ball.x - paddle.x) < paddle.w / 2 + ball.r
        ) {
          const rel = (ball.x - paddle.x) / (paddle.w / 2);
          const a = -Math.PI / 2 + clamp(rel, -1, 1) * 1.05;
          ball.vx = Math.cos(a) * speed;
          ball.vy = Math.sin(a) * speed;
          Sfx.bounce();
        }
        for (const b of bricks) {
          if (b.hp <= 0) continue;
          if (ball.x + ball.r > b.x && ball.x - ball.r < b.x + b.w && ball.y + ball.r > b.y && ball.y - ball.r < b.y + b.h) {
            hitBrick(b);
            break;
          }
        }
        if (ball.y - ball.r > h) break;
      }

      bricks = bricks.filter((b) => b.hp > 0);
      if (!bricks.length) {
        level++;
        speed *= 1.06;
        buildBricks();
        resetBall();
        return;
      }
      if (ball.y - ball.r > h) {
        lives--;
        if (lives <= 0) {
          state = "over";
          Sfx.over();
          api.gameOver(score);
        } else {
          Sfx.hit();
          resetBall();
        }
      }
    }

    function draw() {
      const { ctx, w, h } = stage;
      const g = ctx.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, "#1d1007");
      g.addColorStop(1, "#140b05");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);

      for (const b of bricks) {
        roundRect(ctx, b.x, b.y, b.w, b.h, 4);
        ctx.fillStyle = b.color;
        ctx.fill();
        ctx.fillStyle = "rgba(255,255,255,0.14)";
        roundRect(ctx, b.x, b.y, b.w, b.h * 0.4, 4);
        ctx.fill();
        if (b.hp > 1) {
          ctx.strokeStyle = "rgba(255,240,200,0.8)";
          ctx.lineWidth = 2;
          roundRect(ctx, b.x + 2, b.y + 2, b.w - 4, b.h - 4, 3);
          ctx.stroke();
        }
      }

      // paddle
      roundRect(ctx, paddle.x - paddle.w / 2, paddle.y - paddle.h / 2, paddle.w, paddle.h, paddle.h / 2);
      ctx.fillStyle = C.ember;
      ctx.fill();

      // ball
      ctx.save();
      ctx.shadowColor = C.lamp;
      ctx.shadowBlur = 12;
      ctx.fillStyle = C.cream;
      ctx.beginPath();
      ctx.arc(ball.x, ball.y, ball.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // HUD
      ctx.fillStyle = C.cream;
      ctx.font = `700 ${Math.min(18, w * 0.042)}px Rubik, sans-serif`;
      ctx.textAlign = "left";
      ctx.fillText("♥".repeat(lives), 12, 22);
      ctx.textAlign = "right";
      ctx.fillText(`Lv ${level}`, w - 12, 22);

      if (state === "ready") overlay("Tung Breaker", "Space or tap to play");
      else if (state === "over") overlay("Game over", `Score ${score}  ·  best ${api.best()}`, "Space or tap to retry");
      else if (stuck) {
        ctx.fillStyle = C.dust;
        ctx.textAlign = "center";
        ctx.font = `600 ${Math.min(16, w * 0.04)}px Rubik, sans-serif`;
        ctx.fillText("Space or tap to launch", w / 2, h * 0.7);
      }
    }

    function overlay(title, line, line2) {
      const { ctx, w, h } = stage;
      ctx.fillStyle = "rgba(10,6,3,0.66)";
      ctx.fillRect(0, 0, w, h);
      ctx.textAlign = "center";
      ctx.fillStyle = C.cream;
      ctx.font = `800 ${Math.min(42, w * 0.09)}px Rubik, sans-serif`;
      ctx.fillText(title, w / 2, h * 0.44);
      ctx.fillStyle = C.paper;
      ctx.font = `600 ${Math.min(18, w * 0.044)}px Rubik, sans-serif`;
      ctx.fillText(line, w / 2, h * 0.53);
      if (line2) {
        ctx.fillStyle = C.dust;
        ctx.font = `500 ${Math.min(15, w * 0.038)}px Rubik, sans-serif`;
        ctx.fillText(line2, w / 2, h * 0.6);
      }
    }

    stage.onresize = () => {
      if (state === "ready") reset();
    };

    const loop = Loop((dt) => {
      update(dt);
      draw();
    });
    loop.start();

    return {
      destroy() {
        loop.stop();
        keys.destroy();
        pointer.destroy();
        stage.destroy();
      },
      pause: () => loop.stop(),
      resume: () => loop.start(),
    };
  },
};
