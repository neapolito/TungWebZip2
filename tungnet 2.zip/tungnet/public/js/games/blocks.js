// Log Stack — a 2048-style sliding puzzle with carved wooden tiles.

import { makeStage, Loop, Keys, Pointer, Sfx, C, randInt, choose, roundRect } from "./engine.js";

const N = 4;
const TILE_COLORS = {
  2: ["#8a5a2e", "#f6e6c8"],
  4: ["#9c6a34", "#f6e6c8"],
  8: ["#b06a2c", "#2a170b"],
  16: ["#c27a2c", "#2a170b"],
  32: ["#d68a2e", "#2a170b"],
  64: ["#e5972e", "#2a170b"],
  128: ["#f2a33a", "#2a170b"],
  256: ["#f6b24e", "#2a170b"],
  512: ["#ffc56e", "#2a170b"],
  1024: ["#ffd28a", "#2a170b"],
  2048: ["#fff0cc", "#2a170b"],
};

export default {
  id: "blocks",
  name: "Log Stack",
  blurb: "Slide the logs together. Same numbers merge — can you stack your way to 2048?",
  tag: "Puzzle",
  controls: "Slide: arrows / W A S D / swipe",
  emoji: "🪵",
  accent: "#f2a33a",

  make(host, api) {
    const stage = makeStage(host);
    const keys = Keys();

    let grid, score, state, won, pop;

    function blank() {
      return Array.from({ length: N }, () => Array(N).fill(0));
    }
    function addTile() {
      const empty = [];
      for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) if (!grid[y][x]) empty.push({ x, y });
      if (!empty.length) return;
      const c = choose(empty);
      grid[c.y][c.x] = Math.random() < 0.9 ? 2 : 4;
      pop = { x: c.x, y: c.y, t: 1 };
    }

    function reset() {
      grid = blank();
      score = 0;
      won = false;
      state = "playing";
      pop = null;
      addTile();
      addTile();
      api.setScore(0);
    }
    reset();

    const rev = (row) => [...row].reverse();
    const cols = () => Array.from({ length: N }, (_, x) => grid.map((r) => r[x]));

    function slide(row) {
      const a = row.filter((v) => v);
      let gained = 0;
      for (let i = 0; i < a.length - 1; i++) {
        if (a[i] === a[i + 1]) {
          a[i] *= 2;
          gained += a[i];
          if (a[i] === 2048) won = true;
          a.splice(i + 1, 1);
        }
      }
      while (a.length < N) a.push(0);
      return { row: a, gained };
    }

    function move(dir) {
      if (state !== "playing") return;
      let moved = false;
      let gained = 0;
      if (dir === "left" || dir === "right") {
        for (let y = 0; y < N; y++) {
          const src = dir === "left" ? grid[y] : rev(grid[y]);
          const { row, gained: g } = slide(src);
          const out = dir === "left" ? row : rev(row);
          if (out.some((v, x) => v !== grid[y][x])) moved = true;
          grid[y] = out;
          gained += g;
        }
      } else {
        const cl = cols();
        for (let x = 0; x < N; x++) {
          const src = dir === "up" ? cl[x] : rev(cl[x]);
          const { row, gained: g } = slide(src);
          const out = dir === "up" ? row : rev(row);
          for (let y = 0; y < N; y++) {
            if (grid[y][x] !== out[y]) moved = true;
            grid[y][x] = out[y];
          }
          gained += g;
        }
      }
      if (moved) {
        score += gained;
        api.setScore(score);
        if (gained) Sfx.pick();
        else Sfx.blip(420);
        addTile();
        if (!canMove()) {
          state = "over";
          Sfx.over();
          api.gameOver(score);
        }
      }
    }

    function canMove() {
      for (let y = 0; y < N; y++)
        for (let x = 0; x < N; x++) {
          if (!grid[y][x]) return true;
          if (x < N - 1 && grid[y][x] === grid[y][x + 1]) return true;
          if (y < N - 1 && grid[y][x] === grid[y + 1][x]) return true;
        }
      return false;
    }

    keys.onLeft(() => move("left"));
    keys.onRight(() => move("right"));
    keys.onUp(() => move("up"));
    keys.onDown(() => move("down"));
    keys.onAction(() => {
      if (state === "over") reset();
    });

    const pointer = Pointer(stage.canvas, {
      swipe: (d) => (state === "over" ? reset() : move(d)),
      tap: () => state === "over" && reset(),
    });

    function draw() {
      const { ctx, w, h } = stage;
      ctx.fillStyle = C.bark;
      ctx.fillRect(0, 0, w, h);
      const size = Math.min(w, h) * 0.9;
      const bx = (w - size) / 2;
      const by = (h - size) / 2;
      const gap = size * 0.03;
      const t = (size - gap * (N + 1)) / N;

      roundRect(ctx, bx, by, size, size, size * 0.04);
      ctx.fillStyle = "#3a2412";
      ctx.fill();

      if (pop) pop.t -= 0.08;

      for (let y = 0; y < N; y++)
        for (let x = 0; x < N; x++) {
          const px = bx + gap + x * (t + gap);
          const py = by + gap + y * (t + gap);
          roundRect(ctx, px, py, t, t, t * 0.14);
          ctx.fillStyle = "rgba(0,0,0,0.25)";
          ctx.fill();
          const v = grid[y][x];
          if (!v) continue;
          const [bg, fg] = TILE_COLORS[v] || ["#fff0cc", "#2a170b"];
          let s = 1;
          if (pop && pop.x === x && pop.y === y && pop.t > 0) s = 1 + pop.t * 0.12;
          ctx.save();
          ctx.translate(px + t / 2, py + t / 2);
          ctx.scale(s, s);
          roundRect(ctx, -t / 2, -t / 2, t, t, t * 0.14);
          ctx.fillStyle = bg;
          ctx.fill();
          ctx.fillStyle = "rgba(255,255,255,0.12)";
          roundRect(ctx, -t / 2, -t / 2, t, t * 0.4, t * 0.14);
          ctx.fill();
          ctx.fillStyle = fg;
          const fs = v >= 1000 ? t * 0.3 : v >= 100 ? t * 0.36 : t * 0.44;
          ctx.font = `800 ${fs}px Rubik, sans-serif`;
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillText(String(v), 0, 2);
          ctx.restore();
          ctx.textBaseline = "alphabetic";
        }

      if (won && state === "playing") {
        ctx.fillStyle = C.ember;
        ctx.font = `700 ${Math.min(18, w * 0.04)}px Rubik, sans-serif`;
        ctx.textAlign = "center";
        ctx.fillText("2048! Keep stacking…", w / 2, by - 8 > 16 ? by - 8 : 18);
      }
      if (state === "over") {
        ctx.fillStyle = "rgba(10,6,3,0.66)";
        ctx.fillRect(0, 0, w, h);
        ctx.textAlign = "center";
        ctx.fillStyle = C.cream;
        ctx.font = `800 ${Math.min(40, w * 0.088)}px Rubik, sans-serif`;
        ctx.fillText("No moves left", w / 2, h * 0.44);
        ctx.fillStyle = C.paper;
        ctx.font = `600 ${Math.min(18, w * 0.044)}px Rubik, sans-serif`;
        ctx.fillText(`Score ${score}  ·  best ${api.best()}`, w / 2, h * 0.53);
        ctx.fillStyle = C.dust;
        ctx.font = `500 ${Math.min(15, w * 0.038)}px Rubik, sans-serif`;
        ctx.fillText("Space or tap for a new board", w / 2, h * 0.6);
      }
    }

    const loop = Loop(() => draw());
    loop.start();

    return {
      destroy() {
        loop.stop();
        keys.destroy();
        pointer.destroy();
        stage.destroy();
      },
      pause: () => loop.stop(),
      resume: () => loop.start(),
    };
  },
};
