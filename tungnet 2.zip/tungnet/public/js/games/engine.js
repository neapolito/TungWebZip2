// Shared toolkit for TungNet's arcade games.
// Each game module default-exports:
//   { id, name, blurb, tag, controls, make(host, api) -> instance }
// where instance has { destroy(), pause?(), resume?() } and the game reports
// progress through api.setScore(n) and api.gameOver(finalScore).

import { settings } from "../store.js";

// On-brand palette so every game looks like it belongs to TungNet.
export const C = {
  night: "#140b05",
  bark: "#1d1007",
  wood: "#6e4220",
  wood2: "#8a5a2e",
  woodDark: "#3e2614",
  lamp: "#f2a33a",
  lampDeep: "#c9781c",
  ember: "#ffd28a",
  cream: "#fff0cc",
  paper: "#f6e6c8",
  ink: "#2a170b",
  dust: "#c9a57d",
  dust2: "#a0805e",
  rust: "#ff9466",
  grass: "#3c5a28",
  grassDark: "#2f4a1f",
  chalk: "#e9e0cc",
};

export const clamp = (v, lo, hi) => (v < lo ? lo : v > hi ? hi : v);
export const lerp = (a, b, t) => a + (b - a) * t;
export const rand = (a = 1, b = 0) => b + Math.random() * (a - b);
export const randInt = (a, b) => Math.floor(rand(a, b + 1));
export const choose = (arr) => arr[Math.floor(Math.random() * arr.length)];
export const dist = (ax, ay, bx, by) => Math.hypot(ax - bx, ay - by);
export const now = () => performance.now() / 1000;

// --- A canvas that fills its host and stays crisp on high-DPI screens -------

export function makeStage(host) {
  const canvas = document.createElement("canvas");
  canvas.className = "game-canvas";
  host.appendChild(canvas);
  const ctx = canvas.getContext("2d");
  const stage = { canvas, ctx, w: 1, h: 1, dpr: 1, onresize: null };

  function resize() {
    const rect = host.getBoundingClientRect();
    const w = Math.max(1, Math.round(rect.width));
    const h = Math.max(1, Math.round(rect.height));
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    stage.w = w;
    stage.h = h;
    stage.dpr = dpr;
    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h * dpr);
    canvas.style.width = w + "px";
    canvas.style.height = h + "px";
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (stage.onresize) stage.onresize(w, h);
  }

  const ro = new ResizeObserver(resize);
  ro.observe(host);
  resize();
  stage.destroy = () => {
    ro.disconnect();
    canvas.remove();
  };
  return stage;
}

// --- Fixed-timestep-ish game loop -------------------------------------------

export function Loop(step) {
  let raf = 0;
  let last = 0;
  let running = false;
  function frame(t) {
    if (!running) return;
    const dt = Math.min(0.05, (t - last) / 1000 || 0);
    last = t;
    step(dt, t / 1000);
    raf = requestAnimationFrame(frame);
  }
  return {
    start() {
      if (running) return;
      running = true;
      last = performance.now();
      raf = requestAnimationFrame(frame);
    },
    stop() {
      running = false;
      cancelAnimationFrame(raf);
    },
    get running() {
      return running;
    },
  };
}

// --- Keyboard -----------------------------------------------------------------

const LEFT = ["ArrowLeft", "KeyA"];
const RIGHT = ["ArrowRight", "KeyD"];
const UP = ["ArrowUp", "KeyW"];
const DOWN = ["ArrowDown", "KeyS"];
const ACTION = ["Space", "Enter"];
const BLOCK = new Set([...LEFT, ...RIGHT, ...UP, ...DOWN, "Space"]);

export function Keys() {
  const held = new Set();
  const press = new Map();
  function fire(code) {
    (press.get(code) || []).forEach((fn) => fn());
    (press.get("*") || []).forEach((fn) => fn(code));
  }
  const onDown = (e) => {
    if (e.repeat) {
      if (BLOCK.has(e.code)) e.preventDefault();
      return;
    }
    if (BLOCK.has(e.code)) e.preventDefault();
    if (!held.has(e.code)) {
      held.add(e.code);
      fire(e.code);
    }
  };
  const onUp = (e) => held.delete(e.code);
  window.addEventListener("keydown", onDown);
  window.addEventListener("keyup", onUp);
  return {
    has: (...codes) => codes.some((c) => held.has(c)),
    left: () => LEFT.some((c) => held.has(c)),
    right: () => RIGHT.some((c) => held.has(c)),
    up: () => UP.some((c) => held.has(c)),
    down: () => DOWN.some((c) => held.has(c)),
    onPress(code, fn) {
      const arr = press.get(code) || [];
      arr.push(fn);
      press.set(code, arr);
    },
    onLeft(fn) {
      LEFT.forEach((c) => this.onPress(c, fn));
    },
    onRight(fn) {
      RIGHT.forEach((c) => this.onPress(c, fn));
    },
    onUp(fn) {
      UP.forEach((c) => this.onPress(c, fn));
    },
    onDown(fn) {
      DOWN.forEach((c) => this.onPress(c, fn));
    },
    onAction(fn) {
      ACTION.forEach((c) => this.onPress(c, fn));
    },
    clear() {
      held.clear();
    },
    destroy() {
      window.removeEventListener("keydown", onDown);
      window.removeEventListener("keyup", onUp);
    },
  };
}

// --- Pointer / touch ----------------------------------------------------------

export function Pointer(el, handlers = {}) {
  let active = false;
  let startX = 0;
  let startY = 0;
  let startT = 0;
  function pos(e) {
    const r = el.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }
  const onDown = (e) => {
    active = true;
    const p = pos(e);
    startX = p.x;
    startY = p.y;
    startT = performance.now();
    el.setPointerCapture?.(e.pointerId);
    handlers.down?.(p.x, p.y);
    e.preventDefault();
  };
  const onMove = (e) => {
    const p = pos(e);
    handlers.move?.(p.x, p.y, active);
  };
  const onUp = (e) => {
    if (!active) return;
    active = false;
    const p = pos(e);
    const dx = p.x - startX;
    const dy = p.y - startY;
    const dt = performance.now() - startT;
    handlers.up?.(p.x, p.y, dx, dy);
    if (Math.hypot(dx, dy) < 12 && dt < 300) handlers.tap?.(p.x, p.y);
    else if (Math.hypot(dx, dy) >= 24) {
      const dir = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? "right" : "left") : dy > 0 ? "down" : "up";
      handlers.swipe?.(dir, dx, dy);
    }
  };
  el.addEventListener("pointerdown", onDown);
  el.addEventListener("pointermove", onMove);
  el.addEventListener("pointerup", onUp);
  el.addEventListener("pointercancel", onUp);
  el.style.touchAction = "none";
  return {
    destroy() {
      el.removeEventListener("pointerdown", onDown);
      el.removeEventListener("pointermove", onMove);
      el.removeEventListener("pointerup", onUp);
      el.removeEventListener("pointercancel", onUp);
    },
  };
}

// --- Sound (tiny WebAudio blips, muted with the site's sound setting) --------

let ac = null;
function audio() {
  if (!settings.sound) return null;
  if (!ac) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    ac = new AC();
  }
  if (ac.state === "suspended") ac.resume().catch(() => {});
  return ac;
}

function tone(freq, dur, type = "square", vol = 0.18, slideTo = null) {
  const a = audio();
  if (!a) return;
  const t = a.currentTime;
  const osc = a.createOscillator();
  const gain = a.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t);
  if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
  gain.gain.setValueAtTime(0.0001, t);
  gain.gain.exponentialRampToValueAtTime(vol, t + 0.01);
  gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  osc.connect(gain).connect(a.destination);
  osc.start(t);
  osc.stop(t + dur + 0.02);
}

export const Sfx = {
  blip: (f = 600) => tone(f, 0.07, "square", 0.16),
  pick: () => tone(760, 0.08, "square", 0.18, 1040),
  score: () => {
    tone(780, 0.09, "square", 0.2, 1100);
    setTimeout(() => tone(1180, 0.12, "square", 0.2), 80);
  },
  hit: () => tone(150, 0.2, "sawtooth", 0.25, 70),
  bounce: () => tone(420, 0.05, "triangle", 0.14),
  over: () => {
    tone(360, 0.18, "sawtooth", 0.2, 180);
    setTimeout(() => tone(200, 0.3, "sawtooth", 0.2, 90), 150);
  },
};

// --- High scores (per game, this browser only) -------------------------------

export function loadBest(id) {
  try {
    return Number(localStorage.getItem("tungnet.hi." + id)) || 0;
  } catch {
    return 0;
  }
}
export function saveBest(id, score) {
  const best = loadBest(id);
  if (score > best) {
    try {
      localStorage.setItem("tungnet.hi." + id, String(score));
    } catch {
      /* ignore */
    }
    return score;
  }
  return best;
}

// --- Drawing helpers ----------------------------------------------------------

export function roundRect(ctx, x, y, w, h, r) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

export function woodGradient(ctx, x, y, w, h, light = C.wood2, dark = C.woodDark) {
  const g = ctx.createLinearGradient(x, y, x, y + h);
  g.addColorStop(0, light);
  g.addColorStop(1, dark);
  return g;
}
