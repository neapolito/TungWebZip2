// Gridiron Dash — an original endless football runner.
// Juke the defense and rack up yards. The field scrolls as you charge upfield.

import { makeStage, Loop, Keys, Pointer, Sfx, C, clamp, rand, roundRect } from "./engine.js";

export default {
  id: "gridiron",
  name: "Gridiron Dash",
  blurb: "Juke the tacklers and run it up the field. Every 100 yards is a touchdown.",
  tag: "Football",
  controls: "Move: arrows / A D / drag · Start: Space / tap",
  emoji: "🏈",
  accent: "#5a8f3a",

  make(host, api) {
    const stage = makeStage(host);
    const keys = Keys();

    let state = "ready";
    let player, tacklers, scroll, speed, yards, lastMile, flash, target, shake;

    function reset() {
      const { w, h } = stage;
      player = { x: w / 2, y: h * 0.74, r: Math.max(10, Math.min(w, h) * 0.035) };
      target = { x: player.x, y: player.y };
      tacklers = [];
      scroll = 0;
      speed = h * 0.42;
      yards = 0;
      lastMile = 0;
      flash = 0;
      shake = 0;
    }
    reset();

    function start() {
      reset();
      state = "playing";
      api.setScore(0);
      Sfx.pick();
    }

    function spawn() {
      const { w, h } = stage;
      const margin = w * 0.1;
      tacklers.push({
        x: rand(margin, w - margin),
        y: -h * 0.08,
        r: player.r * rand(0.95, 1.25),
        vx: rand(-40, 40),
        vy: speed * rand(0.55, 0.95),
      });
    }

    let spawnTimer = 0;

    function update(dt) {
      if (state !== "playing") return;
      const { w, h } = stage;

      // Movement: keyboard nudges a target the runner eases toward.
      const step = w * 0.9 * dt;
      if (keys.left()) target.x -= step;
      if (keys.right()) target.x += step;
      if (keys.up()) target.y -= step;
      if (keys.down()) target.y += step;
      target.x = clamp(target.x, w * 0.08, w * 0.92);
      target.y = clamp(target.y, h * 0.45, h * 0.9);
      player.x += (target.x - player.x) * Math.min(1, dt * 12);
      player.y += (target.y - player.y) * Math.min(1, dt * 12);

      // Field + score.
      speed += dt * 6;
      scroll += speed * dt;
      yards += (speed * dt) / 11;
      api.setScore(Math.floor(yards));
      if (Math.floor(yards / 100) > lastMile) {
        lastMile = Math.floor(yards / 100);
        flash = 1.1;
        speed *= 1.05;
        Sfx.score();
      }
      if (flash > 0) flash -= dt;

      // Tacklers.
      spawnTimer -= dt;
      const rate = clamp(0.62 - lastMile * 0.03, 0.26, 0.62);
      if (spawnTimer <= 0) {
        spawn();
        spawnTimer = rand(rate * 0.7, rate * 1.3);
      }
      for (const t of tacklers) {
        t.y += t.vy * dt;
        t.x += t.vx * dt;
        if (t.x < w * 0.06 || t.x > w * 0.94) t.vx *= -1;
        const d = Math.hypot(t.x - player.x, t.y - player.y);
        if (d < t.r + player.r * 0.82) {
          state = "over";
          shake = 1;
          Sfx.over();
          api.gameOver(Math.floor(yards));
        }
      }
      tacklers = tacklers.filter((t) => t.y < h + t.r);
      if (shake > 0) shake -= dt * 2;
    }

    function drawField(ctx, w, h) {
      ctx.fillStyle = C.grass;
      ctx.fillRect(0, 0, w, h);
      // mowing stripes
      const band = Math.max(28, h * 0.1);
      for (let i = -2; i < h / band + 2; i++) {
        const y = ((i * band - (scroll % (band * 2))) % (h + band * 2)) - band;
        ctx.fillStyle = i % 2 ? "rgba(255,255,255,0.04)" : "rgba(0,0,0,0.06)";
        ctx.fillRect(0, y, w, band);
      }
      // yard lines
      ctx.strokeStyle = "rgba(255,255,255,0.5)";
      ctx.lineWidth = 2;
      const gap = h * 0.2;
      for (let i = -1; i < h / gap + 2; i++) {
        const y = ((i * gap - (scroll % gap)) % (h + gap)) ;
        ctx.beginPath();
        ctx.moveTo(w * 0.06, y);
        ctx.lineTo(w * 0.94, y);
        ctx.stroke();
      }
      // sidelines
      ctx.fillStyle = "rgba(255,255,255,0.65)";
      ctx.fillRect(w * 0.055, 0, 3, h);
      ctx.fillRect(w * 0.942, 0, 3, h);
    }

    function drawRunner(ctx, p, color, jersey) {
      ctx.save();
      ctx.translate(p.x, p.y);
      // shadow
      ctx.fillStyle = "rgba(0,0,0,0.3)";
      ctx.beginPath();
      ctx.ellipse(0, p.r * 0.95, p.r * 0.9, p.r * 0.35, 0, 0, Math.PI * 2);
      ctx.fill();
      // body
      ctx.fillStyle = color;
      roundRect(ctx, -p.r * 0.7, -p.r * 0.2, p.r * 1.4, p.r * 1.3, p.r * 0.35);
      ctx.fill();
      // helmet
      ctx.fillStyle = jersey;
      ctx.beginPath();
      ctx.arc(0, -p.r * 0.55, p.r * 0.62, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    function draw() {
      const { ctx, w, h } = stage;
      ctx.save();
      if (shake > 0) ctx.translate(rand(-5, 5) * shake, rand(-5, 5) * shake);
      drawField(ctx, w, h);

      for (const t of tacklers) drawRunner(ctx, t, "#2b3b66", "#1a2440");
      drawRunner(ctx, player, C.lamp, C.ink);

      if (flash > 0) {
        ctx.fillStyle = `rgba(242,163,58,${Math.min(0.5, flash * 0.45)})`;
        ctx.fillRect(0, 0, w, h);
        ctx.fillStyle = C.cream;
        ctx.font = `800 ${Math.min(54, w * 0.1)}px Rubik, sans-serif`;
        ctx.textAlign = "center";
        ctx.fillText("TOUCHDOWN!", w / 2, h * 0.3);
      }
      ctx.restore();

      if (state === "ready") overlay("Gridiron Dash", "Press Space or tap to kick off");
      else if (state === "over")
        overlay("Tackled!", `${Math.floor(yards)} yards  ·  best ${api.best()}`, "Space or tap to run again");
    }

    function overlay(title, line, line2) {
      const { ctx, w, h } = stage;
      ctx.fillStyle = "rgba(10,6,3,0.62)";
      ctx.fillRect(0, 0, w, h);
      ctx.textAlign = "center";
      ctx.fillStyle = C.cream;
      ctx.font = `800 ${Math.min(46, w * 0.095)}px Rubik, sans-serif`;
      ctx.fillText(title, w / 2, h * 0.42);
      ctx.fillStyle = C.paper;
      ctx.font = `600 ${Math.min(20, w * 0.045)}px Rubik, sans-serif`;
      ctx.fillText(line, w / 2, h * 0.52);
      if (line2) {
        ctx.fillStyle = C.dust;
        ctx.font = `500 ${Math.min(16, w * 0.04)}px Rubik, sans-serif`;
        ctx.fillText(line2, w / 2, h * 0.6);
      }
    }

    const loop = Loop((dt) => {
      update(dt);
      draw();
    });

    function go() {
      if (state === "playing") return;
      start();
    }
    keys.onAction(go);

    const pointer = Pointer(stage.canvas, {
      down: (x, y) => {
        if (state !== "playing") go();
        else {
          target.x = x;
          target.y = y;
        }
      },
      move: (x, y, active) => {
        if (active && state === "playing") {
          target.x = x;
          target.y = y;
        }
      },
    });

    loop.start();

    return {
      destroy() {
        loop.stop();
        keys.destroy();
        pointer.destroy();
        stage.destroy();
      },
      pause: () => loop.stop(),
      resume: () => loop.start(),
    };
  },
};
