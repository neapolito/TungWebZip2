// Tung Flap — tap to flap Tung through the gaps between the posts.

import { makeStage, Loop, Keys, Pointer, Sfx, C, clamp, rand, roundRect } from "./engine.js";

export default {
  id: "flap",
  name: "Tung Flap",
  blurb: "Tap to flap. Thread Tung through the gaps in the fence posts.",
  tag: "Arcade",
  controls: "Flap: Space / click / tap",
  emoji: "🪵",
  accent: "#f6b24e",

  make(host, api) {
    const stage = makeStage(host);
    const keys = Keys();
    const face = new Image();
    face.src = "/img/tung-face.png";

    let state = "ready";
    let bird, posts, score, spawnX, gap, speed, rot;

    function reset() {
      const { w, h } = stage;
      bird = { x: w * 0.28, y: h * 0.45, r: Math.max(12, Math.min(w, h) * 0.035), vy: 0 };
      posts = [];
      score = 0;
      gap = h * 0.32;
      speed = w * 0.34;
      rot = 0;
      spawnX = w;
      api.setScore(0);
    }
    reset();

    function flap() {
      if (state === "ready" || state === "over") {
        reset();
        state = "playing";
        bird.vy = -stage.h * 0.62;
        Sfx.pick();
        return;
      }
      bird.vy = -stage.h * 0.62;
      Sfx.blip(620);
    }
    keys.onAction(flap);
    const pointer = Pointer(stage.canvas, { down: flap });

    function addPost() {
      const { w, h } = stage;
      const margin = h * 0.12;
      const gy = rand(margin + gap / 2, h - margin - gap / 2);
      posts.push({ x: w + w * 0.1, gy, passed: false });
    }

    function update(dt) {
      if (state !== "playing") return;
      const { w, h } = stage;
      bird.vy += h * 1.9 * dt;
      bird.y += bird.vy * dt;
      rot = clamp(bird.vy / (h * 0.9), -0.5, 0.9);

      spawnX -= speed * dt;
      if (spawnX <= 0) {
        addPost();
        spawnX = w * 0.46;
      }
      for (const p of posts) {
        p.x -= speed * dt;
        if (!p.passed && p.x < bird.x) {
          p.passed = true;
          score++;
          api.setScore(score);
          gap = Math.max(h * 0.22, gap - h * 0.004);
          speed += w * 0.004;
          Sfx.score();
        }
        // collision with either post
        const pw = w * 0.14;
        if (bird.x + bird.r > p.x && bird.x - bird.r < p.x + pw) {
          if (bird.y - bird.r < p.gy - gap / 2 || bird.y + bird.r > p.gy + gap / 2) {
            die();
          }
        }
      }
      posts = posts.filter((p) => p.x > -w * 0.2);
      if (bird.y + bird.r > h || bird.y - bird.r < 0) die();
    }

    function die() {
      if (state !== "playing") return;
      state = "over";
      Sfx.over();
      api.gameOver(score);
    }

    function draw() {
      const { ctx, w, h } = stage;
      // dusk sky
      const g = ctx.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, "#2a1a0d");
      g.addColorStop(0.6, "#3a2410");
      g.addColorStop(1, "#1d1007");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);
      // lamp glow top-left
      const rg = ctx.createRadialGradient(w * 0.2, h * 0.15, 0, w * 0.2, h * 0.15, w * 0.5);
      rg.addColorStop(0, "rgba(242,163,58,0.25)");
      rg.addColorStop(1, "transparent");
      ctx.fillStyle = rg;
      ctx.fillRect(0, 0, w, h);

      const pw = w * 0.14;
      for (const p of posts) {
        ctx.fillStyle = "#6e4220";
        // top post
        roundRect(ctx, p.x, 0, pw, p.gy - gap / 2, 6);
        ctx.fill();
        roundRect(ctx, p.x - 4, p.gy - gap / 2 - 18, pw + 8, 18, 5);
        ctx.fill();
        // bottom post
        roundRect(ctx, p.x, p.gy + gap / 2, pw, h - (p.gy + gap / 2), 6);
        ctx.fill();
        roundRect(ctx, p.x - 4, p.gy + gap / 2, pw + 8, 18, 5);
        ctx.fill();
        ctx.fillStyle = "rgba(255,255,255,0.08)";
        roundRect(ctx, p.x, 0, pw * 0.3, p.gy - gap / 2, 6);
        ctx.fill();
        roundRect(ctx, p.x, p.gy + gap / 2, pw * 0.3, h - (p.gy + gap / 2), 6);
        ctx.fill();
      }

      // bird (Tung)
      ctx.save();
      ctx.translate(bird.x, bird.y);
      ctx.rotate(rot);
      ctx.shadowColor = "rgba(0,0,0,0.5)";
      ctx.shadowBlur = 10;
      if (face.complete && face.naturalWidth) {
        ctx.drawImage(face, -bird.r, -bird.r, bird.r * 2, bird.r * 2);
      } else {
        ctx.fillStyle = C.lamp;
        ctx.beginPath();
        ctx.arc(0, 0, bird.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      ctx.fillStyle = C.cream;
      ctx.textAlign = "center";
      ctx.font = `800 ${Math.min(40, w * 0.1)}px Rubik, sans-serif`;
      if (state === "playing") ctx.fillText(String(score), w / 2, h * 0.14);

      if (state === "ready") overlay("Tung Flap", "Tap or Space to flap");
      else if (state === "over") overlay("Bonk!", `Score ${score}  ·  best ${api.best()}`, "Tap or Space to fly again");
    }

    function overlay(title, line, line2) {
      const { ctx, w, h } = stage;
      ctx.fillStyle = "rgba(10,6,3,0.62)";
      ctx.fillRect(0, 0, w, h);
      ctx.textAlign = "center";
      ctx.fillStyle = C.cream;
      ctx.font = `800 ${Math.min(42, w * 0.09)}px Rubik, sans-serif`;
      ctx.fillText(title, w / 2, h * 0.42);
      ctx.fillStyle = C.paper;
      ctx.font = `600 ${Math.min(18, w * 0.044)}px Rubik, sans-serif`;
      ctx.fillText(line, w / 2, h * 0.52);
      if (line2) {
        ctx.fillStyle = C.dust;
        ctx.font = `500 ${Math.min(15, w * 0.038)}px Rubik, sans-serif`;
        ctx.fillText(line2, w / 2, h * 0.59);
      }
    }

    stage.onresize = () => {
      if (state === "ready") reset();
    };

    const loop = Loop((dt) => {
      update(dt);
      draw();
    });
    loop.start();

    return {
      destroy() {
        loop.stop();
        keys.destroy();
        pointer.destroy();
        stage.destroy();
      },
      pause: () => loop.stop(),
      resume: () => loop.start(),
    };
  },
};
