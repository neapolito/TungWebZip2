// Tung Hoops — original basketball. Lock the angle, lock the power, drain it.
// One button: tap/Space to set the aim, again to set the power, and it shoots.

import { makeStage, Loop, Keys, Pointer, Sfx, C, clamp, roundRect } from "./engine.js";

export default {
  id: "hoops",
  name: "Tung Hoops",
  blurb: "Tap once for the angle, once for the power. Sink as many as you can in 60 seconds.",
  tag: "Basketball",
  controls: "Shoot: Space / click / tap (twice)",
  emoji: "🏀",
  accent: "#e07b2a",

  make(host, api) {
    const stage = makeStage(host);
    const keys = Keys();

    let state = "ready"; // ready | aim | power | fly | over
    let makes, streak, timeLeft, ball, hoop, ang, pow, angDir, powDir, vel, msg, msgT;

    function layout() {
      const { w, h } = stage;
      const br = Math.max(9, Math.min(w, h) * 0.03);
      ball = { x: w * 0.5, y: h * 0.86, r: br, vx: 0, vy: 0 };
      hoop = { x: w * 0.5, y: h * 0.26, rw: Math.max(26, w * 0.075), drift: 0, dir: 1 };
    }

    function reset() {
      makes = 0;
      streak = 0;
      timeLeft = 60;
      msg = "";
      msgT = 0;
      layout();
      newShot();
    }
    reset();

    function newShot() {
      const { w, h } = stage;
      ball.x = w * 0.5;
      ball.y = h * 0.86;
      ball.vx = ball.vy = 0;
      ang = 90;
      pow = 0.1;
      angDir = 1;
      powDir = 1;
      state = "aim";
    }

    function start() {
      reset();
      state = "aim";
      api.setScore(0);
      Sfx.pick();
    }

    function shoot() {
      const { w, h } = stage;
      const a = (ang * Math.PI) / 180;
      const base = Math.min(w, h) * 2.05;
      const speed = base * (0.42 + pow * 0.72);
      vel = { x: Math.cos(a) * speed, y: -Math.sin(a) * speed };
      ball.vx = vel.x;
      ball.vy = vel.y;
      state = "fly";
      ball.wasAbove = ball.y > hoop.y;
      ball.scored = false;
      Sfx.blip(520);
    }

    function flash(text) {
      msg = text;
      msgT = 1;
    }

    function update(dt) {
      const { w, h } = stage;
      if (msgT > 0) msgT -= dt;

      if (state === "aim" || state === "power" || state === "fly") {
        timeLeft -= dt;
        if (timeLeft <= 0) {
          timeLeft = 0;
          state = "over";
          Sfx.over();
          api.gameOver(makes);
        }
      }
      // Hoop drifts once you're hot.
      if (makes >= 3 && state !== "over" && state !== "ready") {
        hoop.drift += hoop.dir * dt * (0.5 + makes * 0.04);
        if (Math.abs(hoop.drift) > 1) hoop.dir *= -1;
        hoop.x = w * 0.5 + hoop.drift * w * 0.26;
      }

      if (state === "aim") {
        ang += angDir * dt * 70;
        if (ang > 125) angDir = -1;
        if (ang < 55) angDir = 1;
      } else if (state === "power") {
        pow += powDir * dt * 1.25;
        if (pow > 1) {
          pow = 1;
          powDir = -1;
        }
        if (pow < 0.1) {
          pow = 0.1;
          powDir = 1;
        }
      } else if (state === "fly") {
        ball.vy += Math.min(w, h) * 3.1 * dt;
        ball.x += ball.vx * dt;
        ball.y += ball.vy * dt;

        // Pass through the rim while descending = bucket.
        if (!ball.scored && ball.vy > 0 && ball.wasAbove && ball.y + ball.r >= hoop.y && ball.y - ball.r <= hoop.y + hoop.r * 2) {
          if (Math.abs(ball.x - hoop.x) < hoop.rw - ball.r * 0.4) {
            ball.scored = true;
            makes++;
            streak++;
            api.setScore(makes);
            flash(streak >= 3 ? `Swish! x${streak}` : "Bucket!");
            Sfx.score();
            setTimeout(() => state !== "over" && newShot(), 420);
            state = "scored";
          }
        }
        // Rim clank (ball hits the two rim ends).
        for (const ex of [hoop.x - hoop.rw, hoop.x + hoop.rw]) {
          const d = Math.hypot(ball.x - ex, ball.y - hoop.y);
          if (d < ball.r + 3 && ball.vy > 0) {
            ball.vx *= 0.4;
            ball.vy *= -0.45;
            ball.y = hoop.y - ball.r - 3;
            Sfx.bounce();
          }
        }
        if (ball.y - ball.r > h || ball.x < -ball.r || ball.x > w + ball.r) {
          streak = 0;
          flash("Miss");
          if (state !== "over") newShot();
        }
      } else if (state === "scored") {
        ball.vy += Math.min(w, h) * 3.1 * dt;
        ball.x += ball.vx * dt;
        ball.y += ball.vy * dt;
      }
    }

    function drawHoop(ctx) {
      const { h } = stage;
      // backboard
      ctx.fillStyle = "rgba(246,230,200,0.9)";
      roundRect(ctx, hoop.x - hoop.rw * 1.2, hoop.y - h * 0.11, hoop.rw * 2.4, h * 0.11, 6);
      ctx.fill();
      ctx.strokeStyle = C.lampDeep;
      ctx.lineWidth = 3;
      roundRect(ctx, hoop.x - hoop.rw * 0.5, hoop.y - h * 0.075, hoop.rw, h * 0.055, 4);
      ctx.stroke();
      // rim
      ctx.strokeStyle = "#ff6a2c";
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.moveTo(hoop.x - hoop.rw, hoop.y);
      ctx.lineTo(hoop.x + hoop.rw, hoop.y);
      ctx.stroke();
      // net
      ctx.strokeStyle = "rgba(255,255,255,0.75)";
      ctx.lineWidth = 1.2;
      for (let i = 0; i <= 6; i++) {
        const t = i / 6;
        ctx.beginPath();
        ctx.moveTo(hoop.x - hoop.rw + t * hoop.rw * 2, hoop.y);
        ctx.lineTo(hoop.x - hoop.rw * 0.55 + t * hoop.rw * 1.1, hoop.y + hoop.r * 2.4);
        ctx.stroke();
      }
    }

    function drawBall(ctx) {
      ctx.save();
      ctx.translate(ball.x, ball.y);
      ctx.fillStyle = "#e07b2a";
      ctx.beginPath();
      ctx.arc(0, 0, ball.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "rgba(40,20,5,0.8)";
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.arc(0, 0, ball.r, 0, Math.PI * 2);
      ctx.moveTo(-ball.r, 0);
      ctx.lineTo(ball.r, 0);
      ctx.moveTo(0, -ball.r);
      ctx.lineTo(0, ball.r);
      ctx.stroke();
      ctx.restore();
    }

    function draw() {
      const { ctx, w, h } = stage;
      // court
      const g = ctx.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, "#7a4a22");
      g.addColorStop(1, "#5a3518");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);
      ctx.strokeStyle = "rgba(255,220,170,0.18)";
      ctx.lineWidth = 2;
      for (let i = 1; i < 8; i++) {
        ctx.beginPath();
        ctx.moveTo((w / 8) * i, 0);
        ctx.lineTo((w / 8) * i, h);
        ctx.stroke();
      }
      ctx.strokeStyle = "rgba(255,220,170,0.3)";
      ctx.beginPath();
      ctx.arc(w / 2, h * 0.86, w * 0.16, Math.PI, 0);
      ctx.stroke();

      drawHoop(ctx);

      // aim arrow / power bar
      if (state === "aim" || state === "power") {
        const a = (ang * Math.PI) / 180;
        const len = h * (0.1 + (state === "power" ? pow * 0.22 : 0.16));
        ctx.strokeStyle = state === "power" ? "#ffd28a" : "rgba(246,230,200,0.7)";
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(ball.x, ball.y);
        ctx.lineTo(ball.x + Math.cos(a) * len, ball.y - Math.sin(a) * len);
        ctx.stroke();
        if (state === "power") {
          // power pill
          const bw = w * 0.4;
          roundRect(ctx, w / 2 - bw / 2, h * 0.94, bw, 10, 5);
          ctx.fillStyle = "rgba(0,0,0,0.4)";
          ctx.fill();
          roundRect(ctx, w / 2 - bw / 2, h * 0.94, bw * pow, 10, 5);
          ctx.fillStyle = C.lamp;
          ctx.fill();
        }
      }

      drawBall(ctx);

      // HUD
      ctx.fillStyle = C.cream;
      ctx.font = `700 ${Math.min(22, w * 0.05)}px Rubik, sans-serif`;
      ctx.textAlign = "left";
      ctx.fillText(`⏱ ${Math.ceil(timeLeft)}s`, 14, 28);
      ctx.textAlign = "right";
      ctx.fillText(`${makes} made`, w - 14, 28);

      if (msgT > 0) {
        ctx.textAlign = "center";
        ctx.fillStyle = `rgba(255,210,138,${Math.min(1, msgT)})`;
        ctx.font = `800 ${Math.min(34, w * 0.08)}px Rubik, sans-serif`;
        ctx.fillText(msg, w / 2, h * 0.46);
      }

      if (state === "ready") overlay("Tung Hoops", "Tap or Space to start");
      else if (state === "over") overlay("Time!", `${makes} buckets  ·  best ${api.best()}`, "Tap or Space to play again");
    }

    function overlay(title, line, line2) {
      const { ctx, w, h } = stage;
      ctx.fillStyle = "rgba(10,6,3,0.62)";
      ctx.fillRect(0, 0, w, h);
      ctx.textAlign = "center";
      ctx.fillStyle = C.cream;
      ctx.font = `800 ${Math.min(44, w * 0.095)}px Rubik, sans-serif`;
      ctx.fillText(title, w / 2, h * 0.44);
      ctx.fillStyle = C.paper;
      ctx.font = `600 ${Math.min(19, w * 0.045)}px Rubik, sans-serif`;
      ctx.fillText(line, w / 2, h * 0.53);
      if (line2) {
        ctx.fillStyle = C.dust;
        ctx.font = `500 ${Math.min(15, w * 0.038)}px Rubik, sans-serif`;
        ctx.fillText(line2, w / 2, h * 0.6);
      }
    }

    function tap() {
      if (state === "ready" || state === "over") return start();
      if (state === "aim") {
        state = "power";
        Sfx.blip(680);
      } else if (state === "power") {
        shoot();
      }
    }

    keys.onAction(tap);
    const pointer = Pointer(stage.canvas, { tap });

    const loop = Loop((dt) => {
      update(dt);
      draw();
    });
    stage.onresize = () => {
      if (state === "ready") layout();
    };
    loop.start();

    return {
      destroy() {
        loop.stop();
        keys.destroy();
        pointer.destroy();
        stage.destroy();
      },
      pause: () => loop.stop(),
      resume: () => loop.start(),
    };
  },
};
